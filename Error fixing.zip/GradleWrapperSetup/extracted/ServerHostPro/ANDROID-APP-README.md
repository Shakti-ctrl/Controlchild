# Child Safety Monitor - Android Client

This folder contains the Android client application for the Child Safety Monitor system. This application is designed to be installed on the child's device and communicates with the Telegram bot server.

## Application Features

- **Location Tracking**: Monitors and reports device location.
- **Call Log Monitoring**: Tracks incoming and outgoing calls.
- **App Usage Monitoring**: Reports installed and used applications.
- **Camera Access**: Can capture photos when requested.
- **Password Protection**: Settings are protected with a password to prevent unauthorized changes.
- **Automatic Startup**: Starts monitoring automatically when the device boots.
- **Transparent Operation**: Shows a persistent notification when monitoring is active.

## Building the Application

### Prerequisites

- Android Studio 4.0 or higher
- JDK 8 or higher
- Android SDK with minimum SDK version 21 (Android 5.0)

### Steps to Build

1. **Open the Project**:
   - Launch Android Studio
   - Select "Open an existing project"
   - Navigate to the `android_app` directory and select it

2. **Configure the Server URL**:
   - Open `app/src/main/java/com/example/childsafetymonitor/utils/SettingsManager.java`
   - Locate the `initializeDefaultSettings()` method
   - Change the server URL to your Replit server URL:
     ```java
     if (getServerUrl().isEmpty()) {
         setServerUrl("https://your-replit-app.replit.app");
     }
     ```

3. **Build the APK**:
   - Go to Build → Build Bundle(s) / APK(s) → Build APK(s)
   - Android Studio will generate an APK file that you can install on Android devices

4. **Install on Device**:
   - Enable "Unknown sources" in your Android device's security settings
   - Transfer the APK file to the device and install it

## Setting Up the Application

1. **Initial Setup**:
   - Launch the app
   - Grant all requested permissions when prompted
   - For usage stats permission, you'll be redirected to system settings

2. **Default Password**:
   - The default password is `123456`
   - You should change this in the Settings (after logging in with the default password)

3. **Server Configuration**:
   - Ensure the server URL is correctly set to your Replit server
   - The app will automatically register with the server when first launched

## Using the Application

1. **Start Monitoring**:
   - Tap "Start Monitoring" on the main screen
   - The service will run in the background and send data to the server
   - A persistent notification will show that monitoring is active

2. **Access Settings**:
   - Tap "Settings" button
   - Enter the password
   - Configure monitoring options and change password

3. **Stop Monitoring**:
   - Tap "Stop Monitoring" to temporarily halt data collection

## Privacy and Ethical Use

This application is intended for legitimate parental monitoring with proper consent. The child should be informed about the monitoring. Unauthorized surveillance may violate privacy laws and regulations.

## Troubleshooting

1. **Permissions Issues**:
   - If monitoring doesn't work, check if all permissions are granted
   - For Android 10+, location access must be set to "Allow all the time"

2. **Background Service Stops**:
   - Some Android systems aggressively kill background services
   - Add the app to the "protected apps" list in battery settings

3. **Server Communication Failures**:
   - Verify the server URL is correct
   - Check internet connectivity on the device
   - Ensure the Replit server is running

## Technical Notes

- The app uses foreground services to maintain persistent operation
- Location updates use both GPS and network providers for accuracy
- All network communications are done asynchronously to avoid UI freezes
- Data is sent to the server in JSON format