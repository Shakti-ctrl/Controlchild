package com.example.childsafetymonitor.utils;

import android.content.Context;
import android.util.Log;

import com.example.childsafetymonitor.api.ApiService;

import java.io.IOException;
import java.security.SecureRandom;
import java.util.Random;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;

/**
 * Manages security features like password verification and 2FA
 */
public class SecurityManager {
    private static final String TAG = "SecurityManager";
    
    private final Context context;
    private final SettingsManager settingsManager;
    private final ScheduledExecutorService executor;
    private final ApiService apiService;
    private final Random random;
    
    public SecurityManager(Context context) {
        this.context = context;
        this.settingsManager = new SettingsManager(context);
        this.executor = Executors.newSingleThreadScheduledExecutor();
        this.apiService = new ApiService(context, settingsManager.getServerUrl());
        this.random = new SecureRandom();
    }
    
    /**
     * Verify the provided password against the stored password
     */
    public boolean verifyPassword(String password) {
        String storedPassword = settingsManager.getPassword();
        return storedPassword.equals(password);
    }
    
    /**
     * Change the password
     */
    public void changePassword(String newPassword) {
        settingsManager.setPassword(newPassword);
    }
    
    /**
     * Generate a random 6-digit code for two-factor authentication
     */
    public String generate2FACode() {
        int code = 100000 + random.nextInt(900000); // Generates a random 6-digit number
        return String.valueOf(code);
    }
    
    /**
     * Enable two-factor authentication with the provided email
     */
    public void enableTwoFactor(String email) {
        settingsManager.setTwoFactorEnabled(true);
        settingsManager.setTwoFactorEmail(email);
        
        // Notify server about 2FA status change
        ApiService.TwoFactorStatus status = new ApiService.TwoFactorStatus(true, email);
        
        executor.execute(() -> {
            try {
                apiService.sendUpdate(settingsManager.getDeviceId(), "2fa_status", status);
            } catch (IOException e) {
                Log.e(TAG, "Error sending 2FA status update", e);
            }
        });
    }
    
    /**
     * Disable two-factor authentication
     */
    public void disableTwoFactor() {
        settingsManager.setTwoFactorEnabled(false);
        
        // Notify server about 2FA status change
        ApiService.TwoFactorStatus status = new ApiService.TwoFactorStatus(false, "");
        
        executor.execute(() -> {
            try {
                apiService.sendUpdate(settingsManager.getDeviceId(), "2fa_status", status);
            } catch (IOException e) {
                Log.e(TAG, "Error sending 2FA status update", e);
            }
        });
    }
    
    /**
     * Verify a two-factor authentication code
     */
    public boolean verify2FACode(String providedCode, String expectedCode) {
        return providedCode.equals(expectedCode);
    }
    
    /**
     * Check if admin notifications are enabled
     */
    public boolean isAdminNotificationEnabled() {
        return true; // Always notify admin about security events
    }
    
    /**
     * Notify the admin about failed password attempts
     */
    public void notifyAdminAboutFailedAttempts(int attemptCount, String packageName) {
        ApiService.CommandResult result = new ApiService.CommandResult(
                "security_alert",
                String.format("Failed password attempts: %d for package: %s", attemptCount, packageName)
        );
        
        executor.execute(() -> {
            try {
                apiService.sendUpdate(settingsManager.getDeviceId(), "command_result", result);
            } catch (IOException e) {
                Log.e(TAG, "Error sending security alert", e);
            }
        });
    }
}