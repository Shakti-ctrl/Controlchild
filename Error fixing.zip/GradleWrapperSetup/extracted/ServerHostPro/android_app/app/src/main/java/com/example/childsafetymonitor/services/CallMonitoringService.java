package com.example.childsafetymonitor.services;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.MediaRecorder;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.telephony.PhoneStateListener;
import android.telephony.TelephonyManager;
import android.util.Base64;
import android.util.Log;

import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;

import com.example.childsafetymonitor.R;
import com.example.childsafetymonitor.api.ApiService;
import com.example.childsafetymonitor.utils.SettingsManager;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

/**
 * Service for monitoring phone calls and recording audio during calls
 */
public class CallMonitoringService extends Service {
    private static final String TAG = "CallMonitoringService";
    
    public static final String ACTION_START_CALL_LISTENING = "com.example.childsafetymonitor.action.START_CALL_LISTENING";
    public static final String ACTION_STOP_CALL_LISTENING = "com.example.childsafetymonitor.action.STOP_CALL_LISTENING";
    
    private static final int NOTIFICATION_ID = 2001;
    private static final String CHANNEL_ID = "call_monitoring_channel";
    
    private static final int SAMPLE_RATE = 16000; // 16kHz
    private static final int CHANNEL_CONFIG = AudioFormat.CHANNEL_IN_MONO;
    private static final int AUDIO_FORMAT = AudioFormat.ENCODING_PCM_16BIT;
    private static final int BUFFER_SIZE = AudioRecord.getMinBufferSize(SAMPLE_RATE, CHANNEL_CONFIG, AUDIO_FORMAT);
    private static final int BYTES_PER_ELEMENT = 2; // 16-bit audio = 2 bytes per sample
    private static final int RECORDING_DURATION_SECONDS = 15; // Record in 15-second chunks
    
    private TelephonyManager telephonyManager;
    private SettingsManager settingsManager;
    private ApiService apiService;
    private ScheduledExecutorService executor;
    private Handler mainHandler;
    
    private boolean isRecording = false;
    private AudioRecord audioRecord;
    private String currentNumber = "Unknown";
    private boolean isCallActive = false;
    
    private final PhoneStateListener phoneStateListener = new PhoneStateListener() {
        @Override
        public void onCallStateChanged(int state, String phoneNumber) {
            switch (state) {
                case TelephonyManager.CALL_STATE_RINGING:
                    // Incoming call
                    handleIncomingCall(phoneNumber);
                    break;
                    
                case TelephonyManager.CALL_STATE_OFFHOOK:
                    // Call answered or outgoing call
                    handleCallStarted(phoneNumber);
                    break;
                    
                case TelephonyManager.CALL_STATE_IDLE:
                    // Call ended or rejected
                    handleCallEnded();
                    break;
            }
        }
    };
    
    @Override
    public void onCreate() {
        super.onCreate();
        
        telephonyManager = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE);
        settingsManager = new SettingsManager(this);
        apiService = new ApiService(this, settingsManager.getServerUrl());
        executor = Executors.newScheduledThreadPool(2);
        mainHandler = new Handler(Looper.getMainLooper());
        
        // Register outgoing call receiver
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(Intent.ACTION_NEW_OUTGOING_CALL);
        registerReceiver(outgoingCallReceiver, intentFilter);
    }
    
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && intent.getAction() != null) {
            switch (intent.getAction()) {
                case ACTION_START_CALL_LISTENING:
                    startCallListening();
                    break;
                    
                case ACTION_STOP_CALL_LISTENING:
                    stopCallListening();
                    break;
            }
        }
        
        // Start as foreground service to prevent system from killing it
        createNotificationChannel();
        startForeground(NOTIFICATION_ID, buildNotification());
        
        return START_STICKY;
    }
    
    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID,
                    "Call Monitoring Service",
                    NotificationManager.IMPORTANCE_LOW
            );
            channel.setDescription("Used for the call monitoring service");
            channel.setSound(null, null);
            
            NotificationManager notificationManager = getSystemService(NotificationManager.class);
            notificationManager.createNotificationChannel(channel);
        }
    }
    
    private Notification buildNotification() {
        return new NotificationCompat.Builder(this, CHANNEL_ID)
                .setContentTitle("Call Monitoring")
                .setContentText("Call monitoring service is running")
                .setSmallIcon(R.drawable.ic_notification)
                .setOngoing(true)
                .build();
    }
    
    private void startCallListening() {
        Log.d(TAG, "Starting call listening");
        
        // Register phone state listener
        if (telephonyManager != null) {
            telephonyManager.listen(phoneStateListener, PhoneStateListener.LISTEN_CALL_STATE);
        }
        
        settingsManager.setCallRecordingEnabled(true);
    }
    
    private void stopCallListening() {
        Log.d(TAG, "Stopping call listening");
        
        // Unregister phone state listener
        if (telephonyManager != null) {
            telephonyManager.listen(phoneStateListener, PhoneStateListener.LISTEN_NONE);
        }
        
        // Stop recording if active
        stopRecording();
        
        settingsManager.setCallRecordingEnabled(false);
        
        // Stop foreground service
        stopForeground(true);
        stopSelf();
    }
    
    private void handleIncomingCall(String phoneNumber) {
        Log.d(TAG, "Incoming call from: " + phoneNumber);
        
        if (phoneNumber != null && !phoneNumber.isEmpty()) {
            currentNumber = phoneNumber;
        } else {
            currentNumber = "Unknown";
        }
        
        // Send notification to server about incoming call
        sendCallStateUpdate("started", currentNumber, "incoming");
    }
    
    private void handleCallStarted(String phoneNumber) {
        Log.d(TAG, "Call started with: " + phoneNumber);
        
        if (phoneNumber != null && !phoneNumber.isEmpty()) {
            currentNumber = phoneNumber;
        }
        
        isCallActive = true;
        
        // Start recording if enabled
        if (settingsManager.isCallRecordingEnabled()) {
            startRecording();
        }
        
        // Send update to server
        sendCallStateUpdate("started", currentNumber, "active");
    }
    
    private void handleCallEnded() {
        Log.d(TAG, "Call ended");
        
        isCallActive = false;
        
        // Stop recording
        stopRecording();
        
        // Send update to server
        sendCallStateUpdate("ended", currentNumber, null);
        
        // Reset current number
        currentNumber = "Unknown";
    }
    
    private void startRecording() {
        if (isRecording) {
            return;
        }
        
        Log.d(TAG, "Starting call recording");
        
        isRecording = true;
        
        // Start recording in a separate thread
        executor.execute(() -> {
            try {
                audioRecord = new AudioRecord(
                        MediaRecorder.AudioSource.VOICE_COMMUNICATION,
                        SAMPLE_RATE,
                        CHANNEL_CONFIG,
                        AUDIO_FORMAT,
                        BUFFER_SIZE
                );
                
                if (audioRecord.getState() != AudioRecord.STATE_INITIALIZED) {
                    Log.e(TAG, "AudioRecord initialization failed");
                    isRecording = false;
                    return;
                }
                
                audioRecord.startRecording();
                
                // Record in chunks and send to server
                while (isRecording && isCallActive) {
                    recordAndSendAudioChunk();
                }
                
                // Cleanup
                if (audioRecord != null) {
                    audioRecord.stop();
                    audioRecord.release();
                    audioRecord = null;
                }
                
            } catch (Exception e) {
                Log.e(TAG, "Error recording call audio", e);
                isRecording = false;
            }
        });
    }
    
    private void recordAndSendAudioChunk() {
        // Calculate buffer size for specified duration
        int bufferSizeInBytes = SAMPLE_RATE * RECORDING_DURATION_SECONDS * BYTES_PER_ELEMENT;
        byte[] audioBuffer = new byte[bufferSizeInBytes];
        
        // Read audio data from the microphone
        int bytesRead = 0;
        int totalBytesRead = 0;
        
        while (totalBytesRead < bufferSizeInBytes && isRecording && isCallActive) {
            bytesRead = audioRecord.read(audioBuffer, totalBytesRead, bufferSizeInBytes - totalBytesRead);
            
            if (bytesRead > 0) {
                totalBytesRead += bytesRead;
            }
        }
        
        // Send audio chunk to server if we read any data
        if (totalBytesRead > 0) {
            sendAudioToServer(audioBuffer, totalBytesRead);
        }
    }
    
    private void sendAudioToServer(byte[] audioData, int length) {
        // Trim buffer to actual data size
        byte[] trimmedData = new byte[length];
        System.arraycopy(audioData, 0, trimmedData, 0, length);
        
        // Create audio update object
        final byte[] finalData = trimmedData;
        
        executor.execute(() -> {
            try {
                // Create JSON data
                JSONObject audioUpdateJson = new JSONObject();
                audioUpdateJson.put("audio", Base64.encodeToString(finalData, Base64.DEFAULT));
                audioUpdateJson.put("number", currentNumber);
                
                // Send update
                apiService.sendUpdate(settingsManager.getDeviceId(), "call_audio", audioUpdateJson);
            } catch (JSONException | IOException e) {
                Log.e(TAG, "Error sending audio to server", e);
            }
        });
    }
    
    private void stopRecording() {
        Log.d(TAG, "Stopping call recording");
        
        isRecording = false;
        
        if (audioRecord != null) {
            try {
                audioRecord.stop();
                audioRecord.release();
                audioRecord = null;
            } catch (Exception e) {
                Log.e(TAG, "Error stopping audio recording", e);
            }
        }
    }
    
    private void sendCallStateUpdate(String state, String number, String callType) {
        executor.execute(() -> {
            try {
                // Create JSON data
                JSONObject callStateJson = new JSONObject();
                callStateJson.put("state", state);
                callStateJson.put("number", number);
                
                if (callType != null) {
                    callStateJson.put("callType", callType);
                }
                
                // For call ended state, include duration if available
                if ("ended".equals(state)) {
                    // In a real app, calculate actual call duration
                    callStateJson.put("duration", "unknown");
                }
                
                // Send update
                apiService.sendUpdate(settingsManager.getDeviceId(), "call_state", callStateJson);
            } catch (JSONException | IOException e) {
                Log.e(TAG, "Error sending call state update", e);
            }
        });
    }
    
    private final BroadcastReceiver outgoingCallReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (intent.getAction().equals(Intent.ACTION_NEW_OUTGOING_CALL)) {
                String phoneNumber = intent.getStringExtra(Intent.EXTRA_PHONE_NUMBER);
                Log.d(TAG, "Outgoing call to: " + phoneNumber);
                
                if (phoneNumber != null && !phoneNumber.isEmpty()) {
                    currentNumber = phoneNumber;
                } else {
                    currentNumber = "Unknown";
                }
                
                // Send notification to server about outgoing call
                sendCallStateUpdate("started", currentNumber, "outgoing");
            }
        }
    };
    
    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
    
    @Override
    public void onDestroy() {
        // Unregister receivers and listeners
        try {
            unregisterReceiver(outgoingCallReceiver);
        } catch (Exception e) {
            Log.e(TAG, "Error unregistering outgoing call receiver", e);
        }
        
        if (telephonyManager != null) {
            telephonyManager.listen(phoneStateListener, PhoneStateListener.LISTEN_NONE);
        }
        
        // Stop recording if active
        stopRecording();
        
        // Clean up resources
        if (executor != null) {
            executor.shutdown();
        }
        
        super.onDestroy();
    }
}