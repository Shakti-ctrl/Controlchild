package com.example.childsafetymonitor;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SwitchCompat;

import com.example.childsafetymonitor.utils.SettingsManager;

/**
 * Activity for app settings
 */
public class SettingsActivity extends AppCompatActivity {
    
    private EditText serverUrlInput;
    private EditText passwordInput;
    private EditText confirmPasswordInput;
    private EditText notificationTitleInput;
    private EditText notificationTextInput;
    
    private SwitchCompat locationSwitch;
    private SwitchCompat callsSwitch;
    private SwitchCompat smsSwitch;
    private SwitchCompat appsSwitch;
    private SwitchCompat cameraSwitch;
    
    private Button saveButton;
    
    private SettingsManager settingsManager;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);
        
        // Initialize settings manager
        settingsManager = new SettingsManager(this);
        
        // Initialize views
        serverUrlInput = findViewById(R.id.server_url_input);
        passwordInput = findViewById(R.id.password_input);
        confirmPasswordInput = findViewById(R.id.confirm_password_input);
        notificationTitleInput = findViewById(R.id.notification_title_input);
        notificationTextInput = findViewById(R.id.notification_text_input);
        
        locationSwitch = findViewById(R.id.location_switch);
        callsSwitch = findViewById(R.id.calls_switch);
        smsSwitch = findViewById(R.id.sms_switch);
        appsSwitch = findViewById(R.id.apps_switch);
        cameraSwitch = findViewById(R.id.camera_switch);
        
        saveButton = findViewById(R.id.save_button);
        
        // Load current settings
        loadSettings();
        
        // Set up save button
        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveSettings();
            }
        });
    }
    
    /**
     * Load current settings into UI
     */
    private void loadSettings() {
        // Server URL
        serverUrlInput.setText(settingsManager.getServerUrl());
        
        // Notification settings
        notificationTitleInput.setText(settingsManager.getNotificationTitle());
        notificationTextInput.setText(settingsManager.getNotificationText());
        
        // Monitoring settings
        locationSwitch.setChecked(settingsManager.isLocationMonitoringEnabled());
        callsSwitch.setChecked(settingsManager.isCallMonitoringEnabled());
        smsSwitch.setChecked(settingsManager.isSmsMonitoringEnabled());
        appsSwitch.setChecked(settingsManager.isAppMonitoringEnabled());
        cameraSwitch.setChecked(settingsManager.isCameraMonitoringEnabled());
    }
    
    /**
     * Save settings from UI to storage
     */
    private void saveSettings() {
        // Validate server URL
        String serverUrl = serverUrlInput.getText().toString().trim();
        if (TextUtils.isEmpty(serverUrl)) {
            serverUrlInput.setError("Server URL is required");
            return;
        }
        
        // Check if password should be updated
        String password = passwordInput.getText().toString().trim();
        String confirmPassword = confirmPasswordInput.getText().toString().trim();
        
        if (!TextUtils.isEmpty(password)) {
            // Password was entered, validate
            if (password.length() < 6) {
                passwordInput.setError("Password must be at least 6 characters");
                return;
            }
            
            if (!password.equals(confirmPassword)) {
                confirmPasswordInput.setError("Passwords do not match");
                return;
            }
        }
        
        // Save server URL
        settingsManager.setServerUrl(serverUrl);
        
        // Save password if entered
        if (!TextUtils.isEmpty(password)) {
            settingsManager.setPassword(password);
        }
        
        // Save notification settings
        String notificationTitle = notificationTitleInput.getText().toString().trim();
        String notificationText = notificationTextInput.getText().toString().trim();
        
        if (!TextUtils.isEmpty(notificationTitle)) {
            settingsManager.setNotificationTitle(notificationTitle);
        }
        
        if (!TextUtils.isEmpty(notificationText)) {
            settingsManager.setNotificationText(notificationText);
        }
        
        // Save monitoring settings
        settingsManager.setLocationMonitoringEnabled(locationSwitch.isChecked());
        settingsManager.setCallMonitoringEnabled(callsSwitch.isChecked());
        settingsManager.setSmsMonitoringEnabled(smsSwitch.isChecked());
        settingsManager.setAppMonitoringEnabled(appsSwitch.isChecked());
        settingsManager.setCameraMonitoringEnabled(cameraSwitch.isChecked());
        
        // Show success message
        Toast.makeText(this, "Settings saved successfully", Toast.LENGTH_SHORT).show();
        
        // Finish activity
        finish();
    }
}