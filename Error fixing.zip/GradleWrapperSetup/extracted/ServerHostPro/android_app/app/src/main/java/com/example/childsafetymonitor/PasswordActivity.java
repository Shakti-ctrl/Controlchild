package com.example.childsafetymonitor;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.childsafetymonitor.services.MonitoringService;
import com.example.childsafetymonitor.utils.SecurityManager;
import com.example.childsafetymonitor.utils.SettingsManager;

public class PasswordActivity extends AppCompatActivity {
    private static final int MAX_PASSWORD_ATTEMPTS = 5;
    private static final long LOCK_DURATION_MS = 60 * 1000; // 1 minute

    private SettingsManager settingsManager;
    private SecurityManager securityManager;
    private EditText passwordInput;
    private Button loginButton;
    private TextView statusText;

    private int failedAttempts = 0;
    private boolean isLocked = false;
    private Handler lockHandler = new Handler();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_password);

        settingsManager = new SettingsManager(this);
        securityManager = new SecurityManager(this);

        passwordInput = findViewById(R.id.password_input);
        loginButton = findViewById(R.id.login_button);
        statusText = findViewById(R.id.status_text);

        setupLoginButton();
        checkMonitoringService();
    }

    private void setupLoginButton() {
        loginButton.setOnClickListener(v -> attemptLogin());
    }

    private void attemptLogin() {
        if (isLocked) {
            Toast.makeText(this, "App is locked. Please try again later.", Toast.LENGTH_SHORT).show();
            return;
        }

        String password = passwordInput.getText().toString();
        
        if (securityManager.verifyPassword(password)) {
            // Password correct
            passwordInput.setText("");
            failedAttempts = 0;
            proceedToMainActivity();
        } else {
            // Password incorrect
            failedAttempts++;
            passwordInput.setText("");
            
            if (failedAttempts >= MAX_PASSWORD_ATTEMPTS) {
                lockApp();
            } else {
                int remainingAttempts = MAX_PASSWORD_ATTEMPTS - failedAttempts;
                statusText.setVisibility(View.VISIBLE);
                statusText.setText("Incorrect password. " + remainingAttempts + " attempts remaining.");
            }
        }
    }

    private void lockApp() {
        isLocked = true;
        loginButton.setEnabled(false);
        passwordInput.setEnabled(false);
        statusText.setVisibility(View.VISIBLE);
        statusText.setText("Too many failed attempts. App locked for 1 minute.");

        // Send notification to admin if enabled
        if (securityManager.isAdminNotificationEnabled()) {
            securityManager.notifyAdminAboutFailedAttempts(
                    failedAttempts, 
                    getApplicationContext().getPackageName());
        }

        lockHandler.postDelayed(this::unlockApp, LOCK_DURATION_MS);
    }

    private void unlockApp() {
        isLocked = false;
        failedAttempts = 0;
        loginButton.setEnabled(true);
        passwordInput.setEnabled(true);
        statusText.setVisibility(View.INVISIBLE);
    }

    private void proceedToMainActivity() {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
        
        // Don't finish if we need to keep the password check when returning
        if (settingsManager.isAlwaysRequirePassword()) {
            // Don't finish
        } else {
            finish();
        }
    }

    private void checkMonitoringService() {
        // If monitoring is enabled and the service is running, 
        // we can start hidden directly without showing UI
        if (settingsManager.isMonitoringEnabled() && 
            MonitoringService.isRunning(this) && 
            settingsManager.isHideAppEnabled() &&
            !settingsManager.isAlwaysRequirePassword()) {
            
            // Start MainActivity but don't show UI
            Intent intent = new Intent(this, MainActivity.class);
            intent.putExtra("auto_hide", true);
            startActivity(intent);
            finish();
        }
    }
    
    // Handle 2FA verification if needed
    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        
        if (intent != null && intent.hasExtra("verify_2fa")) {
            String action = intent.getStringExtra("action");
            String verificationCode = intent.getStringExtra("code");
            
            // Show 2FA dialog
            show2FADialog(action, verificationCode);
        }
    }
    
    private void show2FADialog(String action, String verificationCode) {
        // In a real app, show a dialog that requests the verification code from the user
        // and compares it with the one provided
        // For now, we'll just show a Toast
        Toast.makeText(this, 
                "2FA Required for: " + action + "\nVerification code: " + verificationCode, 
                Toast.LENGTH_LONG).show();
    }

    @Override
    protected void onDestroy() {
        lockHandler.removeCallbacksAndMessages(null);
        super.onDestroy();
    }
}