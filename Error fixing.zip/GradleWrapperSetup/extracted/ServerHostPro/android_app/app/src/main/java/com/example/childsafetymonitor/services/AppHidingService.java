package com.example.childsafetymonitor.services;

import android.app.Service;
import android.content.ComponentName;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.IBinder;
import android.util.Log;

import androidx.annotation.Nullable;

import com.example.childsafetymonitor.MainActivity;
import com.example.childsafetymonitor.api.ApiService;
import com.example.childsafetymonitor.utils.SettingsManager;

import java.io.IOException;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;

/**
 * Service to hide and unhide the app from the launcher
 */
public class AppHidingService extends Service {
    private static final String TAG = "AppHidingService";
    
    public static final String ACTION_HIDE_APP = "com.example.childsafetymonitor.action.HIDE_APP";
    public static final String ACTION_UNHIDE_APP = "com.example.childsafetymonitor.action.UNHIDE_APP";
    
    private SettingsManager settingsManager;
    private ScheduledExecutorService executor;
    private ApiService apiService;
    
    @Override
    public void onCreate() {
        super.onCreate();
        settingsManager = new SettingsManager(this);
        executor = Executors.newSingleThreadScheduledExecutor();
        apiService = new ApiService(this, settingsManager.getServerUrl());
    }
    
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && intent.getAction() != null) {
            switch (intent.getAction()) {
                case ACTION_HIDE_APP:
                    hideApp();
                    break;
                case ACTION_UNHIDE_APP:
                    unhideApp();
                    break;
            }
        }
        
        // Stop service after processing
        stopSelf();
        
        return START_NOT_STICKY;
    }
    
    /**
     * Hide the app from the launcher
     */
    private void hideApp() {
        Log.d(TAG, "Hiding app from launcher");
        
        // Hide by disabling the launcher activity component
        PackageManager packageManager = getPackageManager();
        ComponentName componentName = new ComponentName(this, MainActivity.class);
        
        packageManager.setComponentEnabledSetting(
                componentName,
                PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
                PackageManager.DONT_KILL_APP
        );
        
        // Update setting
        settingsManager.setHideAppEnabled(true);
        
        // Notify server that app is hidden
        notifyServerAppHidden();
    }
    
    /**
     * Unhide the app in the launcher
     */
    private void unhideApp() {
        Log.d(TAG, "Showing app in launcher");
        
        // Show by enabling the launcher activity component
        PackageManager packageManager = getPackageManager();
        ComponentName componentName = new ComponentName(this, MainActivity.class);
        
        packageManager.setComponentEnabledSetting(
                componentName,
                PackageManager.COMPONENT_ENABLED_STATE_ENABLED,
                PackageManager.DONT_KILL_APP
        );
        
        // Update setting
        settingsManager.setHideAppEnabled(false);
        
        // Notify server that app is unhidden
        notifyServerAppUnhidden();
    }
    
    /**
     * Notify server that app is hidden
     */
    private void notifyServerAppHidden() {
        executor.execute(() -> {
            try {
                apiService.sendUpdate(settingsManager.getDeviceId(), "app_hidden", null);
            } catch (IOException e) {
                Log.e(TAG, "Error sending app hidden update", e);
            }
        });
    }
    
    /**
     * Notify server that app is unhidden
     */
    private void notifyServerAppUnhidden() {
        executor.execute(() -> {
            try {
                apiService.sendUpdate(settingsManager.getDeviceId(), "app_unhidden", null);
            } catch (IOException e) {
                Log.e(TAG, "Error sending app unhidden update", e);
            }
        });
    }
    
    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
    
    @Override
    public void onDestroy() {
        if (executor != null) {
            executor.shutdown();
        }
        super.onDestroy();
    }
}