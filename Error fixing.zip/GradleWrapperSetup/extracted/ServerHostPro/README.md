# Parental Control Application

A comprehensive parental control solution with a Telegram bot interface and Android companion app.

## System Overview

This system consists of two main components:

1. **Telegram Bot Server**: The control panel for parents to monitor and manage their children's devices.
2. **Android Companion App**: The app installed on children's devices that collects data and sends it to the server.

## Server Setup Instructions

### 1. Create a Telegram Bot

1. Talk to [BotFather](https://t.me/botfather) on Telegram
2. Use the `/newbot` command to create a new bot
3. Copy the API token provided by BotFather

### 2. Configure the Bot Server

1. Add your Telegram Bot Token to the `data.json` file:
```json
{
  "botToken": "YOUR_BOT_TOKEN_HERE",
  "webhookUrl": "YOUR_REPLIT_URL"
}
```

2. Deploy the server to Replit or any other hosting service
3. Start the bot and send `/start` to register yourself as the admin

## Android Companion App

### Required Permissions

The Android app requires the following permissions to function properly:

- Location access (Fine and Background)
- Call logs access
- SMS access
- Camera access
- Storage access
- Usage stats access
- Accessibility service
- Device admin rights

### Installation Instructions

1. Build the Android app using Android Studio
2. Install the app on the child's device
3. Grant all required permissions during setup
4. Set a parent password for app protection
5. Connect the app to your server by entering the server URL

### Security Features

- Password protection prevents unauthorized changes
- Persistent notification shows the app is running
- Device administrator rights prevent uninstallation
- Data encryption for sensitive information

## Usage Guide

### Monitoring Features

- **Location Tracking**: View the real-time location of the device
- **Call Logs**: See incoming and outgoing calls
- **Message Monitoring**: View SMS and messaging app content
- **Camera Access**: Take photos using the device's cameras
- **Screenshot Capture**: View what's on the device's screen
- **App Usage Statistics**: Monitor which apps are being used and for how long
- **File Browser**: Access files and photos on the device
- **Remote Control**: Perform actions on the device remotely

### Commands

Use these commands in the Telegram bot to control the monitoring functions:

- `/devices` - List connected devices
- `/location [deviceId]` - Get device location
- `/screenshot [deviceId]` - Capture device screen
- `/calls [deviceId]` - Get call history
- `/camera [deviceId] [front|back]` - Take photo with camera

## Important Notes

⚠️ This application is designed for legitimate parental monitoring purposes only and should be used with proper disclosure to the child being monitored.

⚠️ Using this application to monitor someone without their knowledge may be illegal in your jurisdiction.
