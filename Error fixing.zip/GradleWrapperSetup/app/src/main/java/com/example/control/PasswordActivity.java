package com.example.control;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.control.utils.SettingsManager;

/**
 * Activity that handles authentication before accessing the main application
 * Used to protect the app from unauthorized access
 */
public class PasswordActivity extends AppCompatActivity {

    private EditText passwordEditText;
    private Button loginButton;
    private SettingsManager settingsManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_password);

        settingsManager = new SettingsManager(this);

        passwordEditText = findViewById(R.id.passwordEditText);
        loginButton = findViewById(R.id.loginButton);

        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                verifyPassword();
            }
        });

        // Check if a default password is being used
        if (settingsManager.getAdminPassword().equals("123456")) {
            // Default password is still in use, prompt to change it
            Toast.makeText(this, R.string.please_set_new_password, Toast.LENGTH_LONG).show();
        }
    }

    private void verifyPassword() {
        String enteredPassword = passwordEditText.getText().toString();
        
        if (enteredPassword.isEmpty()) {
            Toast.makeText(this, R.string.password_cannot_be_empty, Toast.LENGTH_SHORT).show();
            return;
        }

        String savedPassword = settingsManager.getAdminPassword();
        
        if (savedPassword.equals("123456")) {
            // First time use or default password, set a new password
            settingsManager.setAdminPassword(enteredPassword);
            Toast.makeText(this, R.string.password_set_successfully, Toast.LENGTH_SHORT).show();
            proceedToMainActivity();
        } else {
            // Verify password against saved one
            if (enteredPassword.equals(savedPassword)) {
                proceedToMainActivity();
            } else {
                Toast.makeText(this, R.string.incorrect_password, Toast.LENGTH_SHORT).show();
                passwordEditText.setText("");
            }
        }
    }

    private void proceedToMainActivity() {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
        finish();
    }
}
