package com.example.control;

import android.content.Context;
import android.os.AsyncTask;
import android.util.Log;

import com.example.control.utils.SettingsManager;

import org.telegram.telegrambots.meta.api.methods.send.SendMessage;
import org.telegram.telegrambots.meta.exceptions.TelegramApiException;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;

public class TelegramBotIntegration {
    private static final String TAG = "TelegramBotIntegration";
    
    private Context context;
    private SettingsManager settingsManager;
    
    // Telegram API constants
    private String botToken;
    private String chatId;
    private final String TELEGRAM_API_URL = "https://api.telegram.org/bot";
    
    public TelegramBotIntegration(Context context) {
        this.context = context;
        this.settingsManager = new SettingsManager(context);
        
        // Get the bot token and chat ID from settings
        this.botToken = settingsManager.getTelegramBotToken();
        this.chatId = settingsManager.getTelegramChatId();
        
        // Set default Telegram bot token if not configured
        if (this.botToken == null || this.botToken.isEmpty()) {
            this.botToken = "8015250284:AAHr177zSbntCMjz8ef-mld0EYJqknP-0dM";
            settingsManager.setTelegramBotToken(this.botToken);
        }
        
        // Set default chat ID if not configured
        if (this.chatId == null || this.chatId.isEmpty()) {
            this.chatId = "6956029558";
            settingsManager.setTelegramChatId(this.chatId);
        }
    }
    
    /**
     * Send a message to the configured Telegram chat
     * 
     * @param message Message to send
     */
    public void sendMessage(String message) {
        if (botToken == null || botToken.isEmpty() || chatId == null || chatId.isEmpty()) {
            Log.e(TAG, "Telegram bot token or chat ID not configured");
            return;
        }
        
        // Send message asynchronously to avoid blocking main thread
        new SendMessageTask().execute(message);
    }
    
    /**
     * Update the Telegram bot token
     * 
     * @param newToken New bot token
     */
    public void updateBotToken(String newToken) {
        if (!newToken.equals(this.botToken)) {
            this.botToken = newToken;
            settingsManager.setTelegramBotToken(newToken);
        }
    }
    
    /**
     * Update the Telegram chat ID
     * 
     * @param newChatId New chat ID
     */
    public void updateChatId(String newChatId) {
        if (!newChatId.equals(this.chatId)) {
            this.chatId = newChatId;
            settingsManager.setTelegramChatId(newChatId);
        }
    }
    
    /**
     * AsyncTask to send messages to Telegram in background
     */
    private class SendMessageTask extends AsyncTask<String, Void, Boolean> {
        @Override
        protected Boolean doInBackground(String... params) {
            String message = params[0];
            
            try {
                String urlString = TELEGRAM_API_URL + botToken + "/sendMessage";
                URL url = new URL(urlString);
                
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("POST");
                connection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
                connection.setDoOutput(true);
                
                String parameters = "chat_id=" + URLEncoder.encode(chatId, "UTF-8") + 
                        "&text=" + URLEncoder.encode(message, "UTF-8");
                
                DataOutputStream outputStream = new DataOutputStream(connection.getOutputStream());
                outputStream.writeBytes(parameters);
                outputStream.flush();
                outputStream.close();
                
                int responseCode = connection.getResponseCode();
                
                if (responseCode == HttpURLConnection.HTTP_OK) {
                    BufferedReader reader = new BufferedReader(
                            new InputStreamReader(connection.getInputStream()));
                    String line;
                    StringBuilder response = new StringBuilder();
                    
                    while ((line = reader.readLine()) != null) {
                        response.append(line);
                    }
                    reader.close();
                    
                    Log.d(TAG, "Telegram API response: " + response.toString());
                    return true;
                } else {
                    Log.e(TAG, "Failed to send message to Telegram. Response code: " + responseCode);
                    return false;
                }
                
            } catch (Exception e) {
                Log.e(TAG, "Error sending message to Telegram: " + e.getMessage());
                return false;
            }
        }
        
        @Override
        protected void onPostExecute(Boolean result) {
            if (result) {
                Log.d(TAG, "Message sent to Telegram successfully");
            } else {
                Log.e(TAG, "Failed to send message to Telegram");
            }
        }
    }
}
