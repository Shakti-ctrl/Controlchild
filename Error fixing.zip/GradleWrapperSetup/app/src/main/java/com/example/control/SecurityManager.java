package com.example.control;

import android.content.Context;
import android.util.Base64;
import android.util.Log;

import com.example.control.utils.SettingsManager;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;

/**
 * Manages security-related operations for the application
 * Handles password hashing, verification, and secure storage
 */
public class SecurityManager {
    private static final String TAG = "SecurityManager";
    
    private Context context;
    private SettingsManager settingsManager;
    
    public SecurityManager(Context context) {
        this.context = context;
        this.settingsManager = new SettingsManager(context);
    }
    
    /**
     * Hash a password with SHA-256 and salt
     * 
     * @param password The plain text password to hash
     * @return The Base64 encoded hashed password with salt
     */
    public String hashPassword(String password) {
        try {
            // Generate a random salt
            SecureRandom random = new SecureRandom();
            byte[] salt = new byte[16];
            random.nextBytes(salt);
            
            // Create MessageDigest instance for SHA-256
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            
            // Add salt to digest
            md.update(salt);
            
            // Get the hash
            byte[] hash = md.digest(password.getBytes(StandardCharsets.UTF_8));
            
            // Combine salt and hash
            byte[] combined = new byte[salt.length + hash.length];
            System.arraycopy(salt, 0, combined, 0, salt.length);
            System.arraycopy(hash, 0, combined, salt.length, hash.length);
            
            // Convert to Base64 for storage
            return Base64.encodeToString(combined, Base64.DEFAULT);
            
        } catch (NoSuchAlgorithmException e) {
            Log.e(TAG, "Error hashing password: " + e.getMessage());
            return null;
        }
    }
    
    /**
     * Verify a password against a stored hash
     * 
     * @param password The plain text password to verify
     * @param storedHash The stored hash to check against
     * @return true if password matches, false otherwise
     */
    public boolean verifyPassword(String password, String storedHash) {
        try {
            // Decode the stored hash
            byte[] combined = Base64.decode(storedHash, Base64.DEFAULT);
            
            // Extract salt (first 16 bytes)
            byte[] salt = new byte[16];
            System.arraycopy(combined, 0, salt, 0, salt.length);
            
            // Extract hash (remaining bytes)
            byte[] hash = new byte[combined.length - salt.length];
            System.arraycopy(combined, salt.length, hash, 0, hash.length);
            
            // Create MessageDigest instance for SHA-256
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            
            // Add salt to digest
            md.update(salt);
            
            // Calculate hash of input password
            byte[] calculatedHash = md.digest(password.getBytes(StandardCharsets.UTF_8));
            
            // Compare calculated hash with stored hash
            if (calculatedHash.length != hash.length) {
                return false;
            }
            
            // Time-constant comparison to prevent timing attacks
            int diff = 0;
            for (int i = 0; i < hash.length; i++) {
                diff |= hash[i] ^ calculatedHash[i];
            }
            
            return diff == 0;
            
        } catch (NoSuchAlgorithmException | IllegalArgumentException e) {
            Log.e(TAG, "Error verifying password: " + e.getMessage());
            return false;
        }
    }
    
    /**
     * Encrypt a sensitive string value
     * 
     * @param plainText The plain text to encrypt
     * @return The encrypted string
     */
    public String encryptString(String plainText) {
        // In a real app, this would use AndroidKeyStore or similar
        // For this implementation, we'll use a simple Base64 encoding
        // as a placeholder for actual encryption
        return Base64.encodeToString(plainText.getBytes(StandardCharsets.UTF_8), Base64.DEFAULT);
    }
    
    /**
     * Decrypt an encrypted string value
     * 
     * @param encryptedText The encrypted text to decrypt
     * @return The decrypted plain text
     */
    public String decryptString(String encryptedText) {
        // In a real app, this would use AndroidKeyStore or similar
        // For this implementation, we'll use a simple Base64 decoding
        // as a placeholder for actual decryption
        try {
            byte[] data = Base64.decode(encryptedText, Base64.DEFAULT);
            return new String(data, StandardCharsets.UTF_8);
        } catch (IllegalArgumentException e) {
            Log.e(TAG, "Error decrypting string: " + e.getMessage());
            return "";
        }
    }
}
