package com.example.control;

import android.content.Context;
import android.util.Log;

import com.example.control.utils.SettingsManager;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import okhttp3.OkHttpClient;
import okhttp3.ResponseBody;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import retrofit2.http.Body;
import retrofit2.http.POST;

public class ApiService {
    private static final String TAG = "ApiService";
    private static ApiService instance;
    private ApiInterface apiInterface;
    private SettingsManager settingsManager;

    // Keep the server URL in a variable so it can be easily updated
    private String serverUrl;

    public interface ApiInterface {
        @POST("api/log-event")
        Call<ResponseBody> logEvent(@Body Map<String, Object> eventData);
    }

    private ApiService(Context context) {
        settingsManager = new SettingsManager(context);
        serverUrl = settingsManager.getServerUrl();
        
        // Setup logging for network requests
        HttpLoggingInterceptor loggingInterceptor = new HttpLoggingInterceptor();
        loggingInterceptor.setLevel(HttpLoggingInterceptor.Level.BODY);
        
        OkHttpClient client = new OkHttpClient.Builder()
                .addInterceptor(loggingInterceptor)
                .build();
        
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(serverUrl)
                .client(client)
                .addConverterFactory(GsonConverterFactory.create())
                .build();
        
        apiInterface = retrofit.create(ApiInterface.class);
    }

    public static synchronized ApiService getInstance(Context context) {
        if (instance == null) {
            instance = new ApiService(context);
        }
        return instance;
    }

    /**
     * Send event data to the server
     * 
     * @param eventType Type of event (call, message, etc.)
     * @param eventData Detailed data about the event
     */
    public void sendEventData(String eventType, String eventData) {
        Map<String, Object> data = new HashMap<>();
        data.put("type", eventType);
        data.put("data", eventData);
        data.put("timestamp", System.currentTimeMillis());
        
        apiInterface.logEvent(data).enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                if (response.isSuccessful()) {
                    Log.d(TAG, "Event data sent successfully");
                } else {
                    try {
                        Log.e(TAG, "Failed to send event data: " + response.errorBody().string());
                    } catch (IOException e) {
                        Log.e(TAG, "Failed to send event data: " + e.getMessage());
                    }
                }
            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {
                Log.e(TAG, "Network error when sending event data: " + t.getMessage());
            }
        });
    }

    /**
     * Update the server URL if it has changed
     * 
     * @param newUrl The new server URL
     */
    public void updateServerUrl(String newUrl) {
        if (!serverUrl.equals(newUrl)) {
            serverUrl = newUrl;
            
            Retrofit retrofit = new Retrofit.Builder()
                    .baseUrl(serverUrl)
                    .addConverterFactory(GsonConverterFactory.create())
                    .build();
            
            apiInterface = retrofit.create(ApiInterface.class);
        }
    }
}
