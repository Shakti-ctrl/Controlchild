package com.example.control;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.util.Log;

import androidx.core.content.ContextCompat;

import com.example.control.utils.SettingsManager;

/**
 * Receiver that runs on device boot to auto-start monitoring services
 * if they were enabled before the device was turned off.
 */
public class BootCompletedReceiver extends BroadcastReceiver {
    private static final String TAG = "BootCompletedReceiver";

    @Override
    public void onReceive(Context context, Intent intent) {
        if (Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction())) {
            Log.d(TAG, "Boot completed event received");
            
            SettingsManager settingsManager = new SettingsManager(context);
            
            // Check if service was enabled before device shutdown
            if (settingsManager.isServiceEnabled()) {
                Log.d(TAG, "Monitoring service was enabled, restarting...");
                
                // Start the monitoring service
                Intent serviceIntent = new Intent(context, MonitoringService.class);
                
                // Starting a foreground service after boot
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    ContextCompat.startForegroundService(context, serviceIntent);
                } else {
                    context.startService(serviceIntent);
                }
                
                Log.d(TAG, "Monitoring service started after boot");
            }
        }
    }
}
